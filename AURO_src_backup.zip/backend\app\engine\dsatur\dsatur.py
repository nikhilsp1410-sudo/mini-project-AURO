"""
DSATUR (Degree of SAturation) graph-colouring heuristic.

Selects the most constrained activity first: highest saturation degree,
tie-break on highest vertex degree, then deterministic id order.
Colours are provisional time-block estimates that guide the CSP solver's
variable ordering — real assignments happen during backtracking.

Implements lazy invalidation: whenever a vertex's saturation changes a
fresh entry is pushed and outdated entries are skipped on pop.
"""

from typing import Dict, List, Set

from ..core.priority_queue import PriorityQueue
from ..graph.conflict_graph import ConflictGraph


def _ascii_sum(s: str) -> int:
    return sum(ord(ch) for ch in s)


def _smallest_available_color(graph: ConflictGraph, vertex_id: str, colors: Dict[str, int]) -> int:
    used = {colors[n] for n in graph.get_neighbors(vertex_id) if n in colors}
    color = 0
    while color in used:
        color += 1
    return color


def run_dsatur(graph: ConflictGraph) -> dict:
    ids = sorted(graph.vertices.keys())
    saturation: Dict[str, Set[int]] = {vid: set() for vid in ids}
    version: Dict[str, int] = {vid: 0 for vid in ids}
    colors: Dict[str, int] = {}
    trace: List[dict] = []

    def priority_of(vid: str) -> tuple:
        return (
            -len(saturation[vid]),
            -graph.get_degree(vid),
            -_ascii_sum(vid),
            version[vid],
        )

    pq: PriorityQueue[str] = PriorityQueue()
    for vid in ids:
        pq.push(vid, priority_of(vid))

    def refresh(vid: str) -> None:
        version[vid] += 1
        pq.push(vid, priority_of(vid))

    step = 0
    while len(colors) < len(ids):
        chosen = None
        while pq.size > 0:
            entry = pq.pop()
            if entry is None:
                break
            vertex_id, priority = entry
            if priority == priority_of(vertex_id):  # stale-entry check
                chosen = vertex_id
                break
        if chosen is None:
            break

        color = _smallest_available_color(graph, chosen, colors)
        colors[chosen] = color
        trace.append(
            {
                "step": step,
                "activityId": chosen,
                "saturation": len(saturation[chosen]),
                "degree": graph.get_degree(chosen),
                "color": color,
            }
        )
        step += 1

        for neighbor in graph.get_neighbors(chosen):
            if neighbor not in colors:
                saturation[neighbor].add(color)
                refresh(neighbor)

    order = [t["activityId"] for t in trace]
    return {"order": order, "provisionalColors": colors, "trace": trace}
