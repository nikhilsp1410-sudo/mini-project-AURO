"""
ResourceRegistry — hash-map indexed lookup over all scheduling resources.

Used by the constraint validator and the solver for O(1) access to
activities, faculty, groups, rooms and the faculty availability matrix.
"""

from typing import Dict, Optional

from .types import (
    Activity,
    Assignment,
    DomainValue,
    Faculty,
    PeriodId,
    Room,
    SchedulingProblem,
    StudentGroup,
    TimeSlot,
)


def slot_key(day: str, period: str) -> str:
    return f"{day}:{period}"


def domain_value_key(v: DomainValue) -> str:
    return f"{v.day}:{v.start}:{v.room_id}"


def assignment_key(a: Assignment) -> str:
    return f"{a.day}:{a.start}:{a.room_id}"


class ResourceRegistry:
    def __init__(self, problem: SchedulingProblem) -> None:
        self.faculty: Dict[str, Faculty] = {f.id: f for f in problem.faculty}
        self.rooms: Dict[str, Room] = {r.id: r for r in problem.rooms}
        self.groups: Dict[str, StudentGroup] = {g.id: g for g in problem.groups}
        self.activities: Dict[str, Activity] = {a.id: a for a in problem.activities}
        self.slots: Dict[str, TimeSlot] = {s.id: s for s in problem.slots}
        self.availability = problem.faculty_availability

    def is_faculty_available(self, faculty_id: str, key: str) -> bool:
        return self.availability.get(faculty_id, {}).get(key, True)

    def get_room(self, room_id: str) -> Optional[Room]:
        return self.rooms.get(room_id)

    def get_activity(self, activity_id: str) -> Optional[Activity]:
        return self.activities.get(activity_id)

    def slot_index(self, period_id: PeriodId) -> int:
        slot = self.slots.get(period_id)
        return slot.index if slot else -1
