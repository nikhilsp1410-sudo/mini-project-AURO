"""
Timetable generation orchestrator.

Pipelines the full DSA flow:
  1. ConflictGraph construction        (O(n^2) edge building)
  2. DSATUR ordering                   (saturation-guided variable order)
  3. CSP domain building               (feasible day/start/room triples)
  4. Backtracking + forward checking   (search with domain pruning)
  5. Hard-constraint validation        (HC-1 .. HC-7)
  6. Soft-constraint scoring           (quality metric)

Only Mode A (initial generation) is implemented — per project scope the
other engines (DBMS / OS) are not part of this service yet.
"""

import time
from datetime import datetime
from typing import List

from ..core.registry import ResourceRegistry
from ..core.types import Assignment, SchedulingProblem
from ..graph.conflict_graph import ConflictGraph
from ..dsatur.dsatur import run_dsatur
from ..csp.domains import build_domains
from ..csp.constraints import compute_soft_score, validate_hard_constraints
from ..csp.backtracking import solve_with_backtracking


def generate_timetable(problem: SchedulingProblem) -> dict:
    start = time.perf_counter()

    registry = ResourceRegistry(problem)
    graph = ConflictGraph.build(problem.activities)
    dsatur = run_dsatur(graph)
    domains = build_domains(problem)

    solve = solve_with_backtracking(problem, dsatur["order"], domains, graph, registry)
    elapsed_ms = (time.perf_counter() - start) * 1000

    vertex_count = len(graph.vertices)
    edge_count = graph.edge_count
    degrees = [graph.get_degree(vid) for vid in graph.vertices]

    assignments: List[Assignment] = solve["assignments"] or []

    metrics = {
        "vertices": vertex_count,
        "edges": edge_count,
        "graphDensity": round((2 * edge_count) / (vertex_count * (vertex_count - 1)), 3) if vertex_count > 1 else 0,
        "edgesByReason": graph.edges_by_reason,
        "maxDegree": max(degrees) if degrees else 0,
        "averageDegree": round(sum(degrees) / len(degrees), 1) if degrees else 0,
        "dsaturOrderFirst": dsatur["order"][:12],
        "iterations": solve["metrics"]["iterations"],
        "backtracks": solve["metrics"]["backtracks"],
        "prunes": solve["metrics"]["prunes"],
        "maxDepth": solve["metrics"]["maxDepth"],
        "elapsedMs": round(elapsed_ms, 1),
        "solved": solve["assignments"] is not None,
    }

    hard_validation = validate_hard_constraints(assignments, problem, registry)
    soft_score = compute_soft_score(assignments, problem, registry)
    soft_score["total"] = round(
        soft_score["facultyPreference"] - soft_score["gapPenalty"] * 4
        - soft_score["loadBalance"] * 3 + soft_score["roomUtilization"] * 0.6, 1
    )

    return {
        "assignments": [
            {
                "activityId": a.activity_id,
                "day": a.day,
                "start": a.start,
                "roomId": a.room_id,
                "periods": a.periods,
            }
            for a in assignments
        ],
        "metrics": metrics,
        "hardValidation": hard_validation,
        "softScore": soft_score,
        "generatedAt": datetime.now().strftime("%a %b %d %Y, %I:%M:%S %p"),
    }
