import {
  Activity,
  Assignment,
  DomainValue,
  Faculty,
  Room,
  SchedulingProblem,
  StudentGroup,
  TimeSlot,
} from './types';

export class ResourceRegistry {
  readonly faculty: Map<string, Faculty> = new Map();
  readonly rooms: Map<string, Room> = new Map();
  readonly groups: Map<string, StudentGroup> = new Map();
  readonly activities: Map<string, Activity> = new Map();
  readonly slots: Map<string, TimeSlot> = new Map();
  readonly availability: Map<string, Map<string, boolean>> = new Map();

  constructor(problem: SchedulingProblem) {
    problem.faculty.forEach((f) => this.faculty.set(f.id, f));
    problem.rooms.forEach((r) => this.rooms.set(r.id, r));
    problem.groups.forEach((g) => this.groups.set(g.id, g));
    problem.activities.forEach((a) => this.activities.set(a.id, a));
    problem.slots.forEach((s) => this.slots.set(s.id, s));
    this.availability = problem.facultyAvailability;
  }

  isFacultyAvailable(facultyId: string, slotKey: string): boolean {
    return this.availability.get(facultyId)?.get(slotKey) ?? true;
  }

  getRoom(roomId: string): Room | undefined {
    return this.rooms.get(roomId);
  }

  getActivity(activityId: string): Activity | undefined {
    return this.activities.get(activityId);
  }
}

export const periodsCovered = (start: string, duration: number, slots: TimeSlot[]): TimeSlot[] => {
  const startIdx = slots.find((s) => s.id === start)?.index ?? -1;
  return slots.filter((s) => s.index >= startIdx && s.index < startIdx + duration);
};

export const slotKey = (day: string, period: string): string => `${day}:${period}`;

export const domainValueKey = (v: DomainValue): string => `${v.day}:${v.start}:${v.roomId}`;

export const assignmentKey = (a: Assignment): string => `${a.day}:${a.start}:${a.roomId}`;
