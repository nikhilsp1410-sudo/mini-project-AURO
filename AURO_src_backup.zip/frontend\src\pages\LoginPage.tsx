import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Mail, Lock, Eye, EyeOff, Loader2, LogIn, AlertCircle, Orbit } from 'lucide-react';

const QUICK_ACCOUNTS = [
  { email: 'admin@auro.edu', password: 'admin123', label: 'Admin' },
  { email: 'coordinator@auro.edu', password: 'coord123', label: 'Coordinator' },
  { email: 'salma@auro.edu', password: 'faculty123', label: 'Faculty' },
  { email: 'student.a@auro.edu', password: 'student123', label: 'Student' },
];

export const LoginPage: React.FC = () => {
  const { login } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setErrorMessage(null);

    const cleanEmail = email.trim().toLowerCase();
    const cleanPass = password.trim();
    if (!cleanEmail || !cleanPass) {
      setErrorMessage('Enter your AURO portal email and password.');
      return;
    }

    setBusy(true);
    const ok = await login(cleanEmail, cleanPass);
    if (!ok) {
      setBusy(false);
      setErrorMessage('Sign-in failed. Verify the credentials issued by the AURO administration.');
    }
  };

  return (
    <div className="min-h-screen bg-paper text-stone-900 relative flex items-center justify-center p-4 selection:bg-brand-600 selection:text-white">
      <div className="absolute inset-0 bg-paper-grid opacity-70 pointer-events-none" />
      <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[720px] h-[420px] rounded-full bg-gradient-to-br from-brand-200/30 via-amber-100/20 to-transparent blur-3xl pointer-events-none" />

      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-6">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-brand-600 to-brand-800 flex items-center justify-center text-white shadow-lg ring-1 ring-brand-900/20">
            <Orbit className="w-7 h-7" />
          </div>
          <h1 className="font-serif text-3xl font-black tracking-tight text-stone-900 mt-4">
            AURO
          </h1>
          <p className="text-[11px] font-mono font-bold tracking-[0.22em] text-brand-700 mt-1 uppercase">
            Autonomous University Resource Orchestrator
          </p>
        </div>

        <div className="rounded-2xl border border-stone-300 bg-[#FDFBF6] shadow-sm overflow-hidden">
          <div className="px-6 pt-5 pb-4 border-b border-stone-200">
            <div className="font-mono text-[10px] font-bold tracking-[0.25em] text-brand-700">
              RESOURCE ORCHESTRATION PORTAL
            </div>
            <div className="font-mono text-[9px] tracking-[0.2em] text-stone-400 mt-1">
              ODD SEMESTER 2026–27 · CAMPUS EDITION
            </div>
          </div>

          <form onSubmit={handleSubmit} className="px-6 pt-5 pb-6 space-y-5">
            <div className="space-y-1.5">
              <label htmlFor="auro-email" className="text-[10px] font-mono font-bold tracking-[0.2em] text-stone-500">
                PORTAL EMAIL
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-stone-400 absolute left-0 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="auro-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); setErrorMessage(null); }}
                  placeholder="you@auro.edu"
                  autoComplete="email"
                  className="ink-field w-full pl-7 pr-2 py-2.5 text-sm font-semibold text-stone-900"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="auro-password" className="text-[10px] font-mono font-bold tracking-[0.2em] text-stone-500">
                PASSWORD
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-stone-400 absolute left-0 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="auro-password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setErrorMessage(null); }}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  className="ink-field w-full pl-7 pr-9 py-2.5 text-sm font-semibold text-stone-900 tracking-widest"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-0 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 cursor-pointer"
                  title={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {errorMessage && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-[11.5px] font-medium">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-px" />
                <span>{errorMessage}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-brand-700 to-brand-800 text-white text-[13px] font-bold tracking-[0.05em] flex items-center justify-center gap-2 transition-all shadow-sm hover:shadow-md hover:-translate-y-px disabled:cursor-not-allowed disabled:opacity-80"
            >
              {busy ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  SIGNING IN…
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  SIGN IN
                </>
              )}
            </button>

            <div className="pt-1 border-t border-stone-100">
              <div className="text-[9px] font-mono font-bold tracking-[0.2em] text-stone-400 text-center pt-3">
                ONE-CLICK DEMO ACCESS
              </div>
              <div className="grid grid-cols-4 gap-1.5 mt-2">
                {QUICK_ACCOUNTS.map((acc) => (
                  <button
                    key={acc.email}
                    type="button"
                    onClick={() => { setEmail(acc.email); setPassword(acc.password); setErrorMessage(null); }}
                    className="px-2 py-1.5 rounded-lg border border-stone-200 bg-white hover:bg-brand-50 hover:border-brand-200 text-[10px] font-bold text-stone-600 hover:text-brand-700 transition-colors cursor-pointer"
                  >
                    {acc.label}
                  </button>
                ))}
              </div>
            </div>
          </form>
        </div>

        <p className="text-center text-[10px] text-stone-400 mt-5 font-medium">
          Students: password <span className="font-mono font-bold text-stone-500">student123</span> · Issued by AURO Department Office
        </p>
      </div>
    </div>
  );
};
