import { Activity, Day, Division, Faculty, PeriodId, Room, SchedulingProblem, StudentGroup, TimeSlot } from '../engine';

export const TIME_SLOTS: TimeSlot[] = [
  { id: 'P1', index: 0, start: '08:00', end: '09:00', label: 'Period 1' },
  { id: 'P2', index: 1, start: '09:00', end: '10:00', label: 'Period 2' },
  { id: 'P3', index: 2, start: '10:30', end: '11:30', label: 'Period 3' },
  { id: 'P4', index: 3, start: '11:30', end: '12:30', label: 'Period 4' },
  { id: 'P5', index: 4, start: '01:30', end: '02:30', label: 'Period 5' },
  { id: 'P6', index: 5, start: '02:30', end: '03:30', label: 'Period 6' },
  { id: 'P7', index: 6, start: '03:30', end: '04:30', label: 'Period 7' },
  { id: 'P8', index: 7, start: '04:30', end: '05:30', label: 'Period 8' },
];

export const DAYS: Day[] = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export const ROOMS: Room[] = [
  { id: 'step-hall', name: 'Step Hall', type: 'lecture-hall', capacity: 130, building: 'Main Building Block A' },
  { id: 'mb204', name: 'MB204', type: 'lecture-hall', capacity: 130, building: 'Main Building Block A' },
  { id: 'mb208', name: 'MB208', type: 'lecture-hall', capacity: 130, building: 'Main Building Block A' },
  { id: 'ai-room', name: 'AI Room', type: 'lecture-hall', capacity: 130, building: 'CS Wing' },
  { id: 'project-lab', name: 'Project Lab', type: 'laboratory', capacity: 130, building: 'CS Wing' },
  { id: 'network-lab', name: 'Network Lab', type: 'laboratory', capacity: 65, building: 'CS Wing' },
  { id: 'dl-gpu-lab', name: 'DL GPU Lab', type: 'laboratory', capacity: 65, building: 'Advanced Computing Center' },
  { id: 'embedded-lab', name: 'Embedded Lab', type: 'laboratory', capacity: 65, building: 'Electronics Wing' },
];

const F = (id: string, name: string, designation: string, unavailableSlots: string[] = [], preferredSlots: string[] = []): Faculty => ({
  id,
  name,
  designation,
  unavailableSlots,
  preferredSlots,
});

export const FACULTY: Faculty[] = [
  F('salma', 'Dr. Salma Shahapur', 'Associate Professor', ['Sat:P1', 'Sat:P2'], ['Mon:P3', 'Tue:P3', 'Wed:P3']),
  F('tabassum', 'Tabassum J', 'Assistant Professor', [], ['Mon:P1', 'Tue:P1']),
  F('prema', 'Dr. Prema T. A.', 'Professor', [], ['Mon:P3', 'Wed:P3']),
  F('swati', 'Swati S', 'Lab Instructor'),
  F('somanatti', 'U. V. Somanatti', 'Associate Professor', [], ['Mon:P3', 'Tue:P3']),
  F('neha', 'Neha Nimbalkar', 'Assistant Professor'),
  F('sakshi', 'Sakshi S', 'Lab Instructor'),
  F('ryan', 'Dr. Ryan Dias', 'Assistant Professor', ['Sat:P5', 'Sat:P6', 'Sat:P7'], ['Mon:P1', 'Fri:P1']),
  F('madhu', 'Madhu S', 'Lab Instructor'),
  F('aarya', 'Aarya G', 'Lab Instructor'),
  F('amey', 'Amey Muchandi', 'Assistant Professor', [], ['Mon:P2', 'Tue:P2']),
  F('akshata', 'Akshata P', 'Lab Instructor'),
  F('supriya_n', 'Supriya N', 'Lab Instructor'),
  F('niranjan', 'Dr. Niranjan Muchandi', 'Professor'),
  F('santosh', 'Dr. Santosh Pattar', 'Associate Professor', ['Sat:P1', 'Sat:P2', 'Sat:P3', 'Sat:P4', 'Sat:P5', 'Sat:P6', 'Sat:P7'], ['Mon:P5', 'Tue:P5']),
  F('ashwini', 'Ashwini B', 'Lab Instructor', ['Sat:P5']),
  F('sushmita', 'Sushmita P', 'Assistant Professor'),
  F('soumya', 'Soumya M', 'Lab Instructor'),
  F('khanai', 'Dr. Rajashri Khanai', 'Professor & HOD', ['Sat:P1', 'Sat:P2'], ['Fri:P5']),
  F('madhurani', 'Madhurani S', 'Assistant Professor'),
  F('shrigouri', 'Shrigouri M', 'Lab Instructor'),
  F('belkar', 'Supriya Belkar', 'Assistant Professor'),
  F('priyanka_patil', 'Priyanka Patil', 'Assistant Professor'),
];

export const STUDENT_GROUPS: StudentGroup[] = [
  { id: 'div-A', division: 'A', batch: 'FULL', size: 120 },
  { id: 'div-A-B1', division: 'A', batch: 'B1', size: 60 },
  { id: 'div-A-B2', division: 'A', batch: 'B2', size: 60 },
  { id: 'div-B', division: 'B', batch: 'FULL', size: 120 },
  { id: 'div-B-B1', division: 'B', batch: 'B1', size: 60 },
  { id: 'div-B-B2', division: 'B', batch: 'B2', size: 60 },
  { id: 'div-C', division: 'C', batch: 'FULL', size: 120 },
  { id: 'div-C-B1', division: 'C', batch: 'B1', size: 60 },
  { id: 'div-C-B2', division: 'C', batch: 'B2', size: 60 },
  { id: 'div-D', division: 'D', batch: 'FULL', size: 80 },
  { id: 'div-D-B1', division: 'D', batch: 'B1', size: 40 },
  { id: 'div-D-B2', division: 'D', batch: 'B2', size: 40 },
];

const DIVISION_HALL: Record<Division, string> = { A: 'step-hall', B: 'mb204', C: 'mb208', D: 'ai-room' };

interface OfferingSpec {
  division: Division;
  courseCode: string;
  courseTitle: string;
  facultyIds: string[];
  theorySessions: number;
  labs: Array<{ duration: number; roomIds: string[]; groupId: string; facultyIds: string[]; sessionType?: 'lab' | 'project' }>;
  miniProject?: { duration: number; roomId: string; facultyIds: string[] };
}

const OFFERINGS: OfferingSpec[] = [
  {
    division: 'A',
    courseCode: '25ECSC309',
    courseTitle: 'Deep Learning',
    facultyIds: ['salma'],
    theorySessions: 3,
    labs: [{ duration: 3, roomIds: ['dl-gpu-lab'], groupId: 'div-A-B1', facultyIds: ['salma', 'tabassum', 'swati'] }],
  },
  {
    division: 'A',
    courseCode: '25ECSC304',
    courseTitle: 'Cryptography & Network Security',
    facultyIds: ['somanatti'],
    theorySessions: 3,
    labs: [{ duration: 2, roomIds: ['network-lab'], groupId: 'div-A-B1', facultyIds: ['somanatti', 'sakshi'] }],
  },
  {
    division: 'A',
    courseCode: '26ECSC313',
    courseTitle: 'Microcontroller & Embedded Systems',
    facultyIds: ['amey'],
    theorySessions: 3,
    labs: [{ duration: 2, roomIds: ['embedded-lab'], groupId: 'div-A-B1', facultyIds: ['amey', 'akshata', 'supriya_n'] }],
  },
  {
    division: 'A',
    courseCode: '26ECSC312',
    courseTitle: 'Wireless & Mobile Networks',
    facultyIds: ['ryan'],
    theorySessions: 2,
    labs: [{ duration: 2, roomIds: ['network-lab'], groupId: 'div-A-B2', facultyIds: ['ryan', 'madhu', 'aarya'] }],
  },
  {
    division: 'A',
    courseCode: '25ECSE347',
    courseTitle: 'Cyber Security',
    facultyIds: ['sushmita'],
    theorySessions: 2,
    labs: [{ duration: 2, roomIds: ['network-lab'], groupId: 'div-A-B2', facultyIds: ['sushmita', 'soumya'] }],
  },
  {
    division: 'A',
    courseCode: '26ECSE346',
    courseTitle: 'AI Assisted Software Development',
    facultyIds: ['santosh'],
    theorySessions: 1,
    labs: [{ duration: 4, roomIds: ['project-lab', 'dl-gpu-lab'], groupId: 'div-A-B1', facultyIds: ['santosh', 'ashwini'] }],
  },
  {
    division: 'A',
    courseCode: '23EHSA303',
    courseTitle: 'ATAR Soft Skills',
    facultyIds: ['priyanka_patil'],
    theorySessions: 1,
    labs: [],
  },
  {
    division: 'A',
    courseCode: '25ECSW301',
    courseTitle: 'Mini Project Evaluation',
    facultyIds: ['khanai'],
    theorySessions: 0,
    labs: [],
    miniProject: { duration: 3, roomId: 'project-lab', facultyIds: ['khanai'] },
  },
  {
    division: 'B',
    courseCode: '25ECSC309',
    courseTitle: 'Deep Learning',
    facultyIds: ['tabassum'],
    theorySessions: 3,
    labs: [{ duration: 2, roomIds: ['dl-gpu-lab'], groupId: 'div-B-B1', facultyIds: ['tabassum', 'salma', 'swati'] }],
  },
  {
    division: 'B',
    courseCode: '25ECSC304',
    courseTitle: 'Cryptography & Network Security',
    facultyIds: ['neha'],
    theorySessions: 3,
    labs: [{ duration: 2, roomIds: ['network-lab'], groupId: 'div-B-B2', facultyIds: ['neha', 'sakshi'] }],
  },
  {
    division: 'B',
    courseCode: '26ECSC313',
    courseTitle: 'Microcontroller & Embedded Systems',
    facultyIds: ['amey'],
    theorySessions: 3,
    labs: [{ duration: 2, roomIds: ['embedded-lab'], groupId: 'div-B-B1', facultyIds: ['amey', 'akshata', 'ashwini'] }],
  },
  {
    division: 'B',
    courseCode: '26ECSC312',
    courseTitle: 'Wireless & Mobile Networks',
    facultyIds: ['madhurani'],
    theorySessions: 2,
    labs: [],
  },
  {
    division: 'B',
    courseCode: '25ECSE347',
    courseTitle: 'Cyber Security',
    facultyIds: ['sushmita'],
    theorySessions: 2,
    labs: [],
  },
  {
    division: 'B',
    courseCode: '26ECSE346',
    courseTitle: 'AI Assisted Software Development',
    facultyIds: ['santosh'],
    theorySessions: 0,
    labs: [{ duration: 4, roomIds: ['project-lab', 'dl-gpu-lab'], groupId: 'div-B-B2', facultyIds: ['santosh', 'ashwini'] }],
  },
  {
    division: 'B',
    courseCode: '23EHSA303',
    courseTitle: 'ATAR Soft Skills',
    facultyIds: ['priyanka_patil'],
    theorySessions: 1,
    labs: [],
  },
  {
    division: 'B',
    courseCode: '25ECSW301',
    courseTitle: 'Mini Project Evaluation',
    facultyIds: ['sushmita'],
    theorySessions: 0,
    labs: [],
    miniProject: { duration: 3, roomId: 'project-lab', facultyIds: ['sushmita'] },
  },
  {
    division: 'C',
    courseCode: '25ECSC309',
    courseTitle: 'Deep Learning',
    facultyIds: ['tabassum'],
    theorySessions: 3,
    labs: [{ duration: 3, roomIds: ['dl-gpu-lab'], groupId: 'div-C-B2', facultyIds: ['tabassum', 'prema', 'swati'] }],
  },
  {
    division: 'C',
    courseCode: '25ECSC304',
    courseTitle: 'Cryptography & Network Security',
    facultyIds: ['neha'],
    theorySessions: 3,
    labs: [],
  },
  {
    division: 'C',
    courseCode: '26ECSC313',
    courseTitle: 'Microcontroller & Embedded Systems',
    facultyIds: ['niranjan'],
    theorySessions: 3,
    labs: [{ duration: 2, roomIds: ['embedded-lab'], groupId: 'div-C-B1', facultyIds: ['niranjan', 'akshata', 'belkar'] }],
  },
  {
    division: 'C',
    courseCode: '26ECSC312',
    courseTitle: 'Wireless & Mobile Networks',
    facultyIds: ['belkar'],
    theorySessions: 2,
    labs: [],
  },
  {
    division: 'C',
    courseCode: '25ECSE347',
    courseTitle: 'Cyber Security',
    facultyIds: ['sushmita'],
    theorySessions: 2,
    labs: [{ duration: 2, roomIds: ['network-lab'], groupId: 'div-C-B1', facultyIds: ['sushmita', 'soumya'] }],
  },
  {
    division: 'C',
    courseCode: '26ECSE346',
    courseTitle: 'AI Assisted Software Development',
    facultyIds: ['santosh'],
    theorySessions: 0,
    labs: [{ duration: 4, roomIds: ['project-lab', 'dl-gpu-lab'], groupId: 'div-C-B2', facultyIds: ['santosh', 'ashwini'] }],
  },
  {
    division: 'C',
    courseCode: '23EHSA303',
    courseTitle: 'ATAR Soft Skills',
    facultyIds: ['priyanka_patil'],
    theorySessions: 1,
    labs: [],
  },
  {
    division: 'C',
    courseCode: '25ECSW301',
    courseTitle: 'Mini Project Evaluation',
    facultyIds: ['niranjan'],
    theorySessions: 0,
    labs: [],
    miniProject: { duration: 3, roomId: 'project-lab', facultyIds: ['niranjan'] },
  },
  {
    division: 'D',
    courseCode: '26ECAC301',
    courseTitle: 'Cloud Computing',
    facultyIds: ['madhurani'],
    theorySessions: 3,
    labs: [{ duration: 2, roomIds: ['network-lab'], groupId: 'div-D-B1', facultyIds: ['madhurani', 'shrigouri'] }],
  },
  {
    division: 'D',
    courseCode: '26ECAC304',
    courseTitle: 'Parallel & GPU Computing',
    facultyIds: ['santosh'],
    theorySessions: 3,
    labs: [{ duration: 2, roomIds: ['dl-gpu-lab'], groupId: 'div-D-B1', facultyIds: ['santosh', 'ashwini'] }],
  },
  {
    division: 'D',
    courseCode: '26ECAC302',
    courseTitle: 'Deep Learning',
    facultyIds: ['prema'],
    theorySessions: 3,
    labs: [{ duration: 3, roomIds: ['dl-gpu-lab'], groupId: 'div-D-B2', facultyIds: ['prema', 'salma', 'swati'] }],
  },
  {
    division: 'D',
    courseCode: '26ECAC305',
    courseTitle: 'Cryptography & Network Security',
    facultyIds: ['somanatti'],
    theorySessions: 2,
    labs: [],
  },
  {
    division: 'D',
    courseCode: '26ECSE346',
    courseTitle: 'AI Assisted Software Development',
    facultyIds: ['santosh'],
    theorySessions: 1,
    labs: [],
  },
  {
    division: 'D',
    courseCode: '23EHSA303',
    courseTitle: 'ATAR Soft Skills',
    facultyIds: ['priyanka_patil'],
    theorySessions: 1,
    labs: [],
  },
  {
    division: 'D',
    courseCode: '22ECAW301',
    courseTitle: 'Mini Project Evaluation',
    facultyIds: ['amey'],
    theorySessions: 0,
    labs: [],
    miniProject: { duration: 3, roomId: 'project-lab', facultyIds: ['amey'] },
  },
];

const UNAVAILABILITY: Array<{ resourceId: string; resourceType: 'faculty' | 'room'; day: Day; period: PeriodId }> = [
  { resourceId: 'project-lab', resourceType: 'room', day: 'Sat', period: 'P1' },
  { resourceId: 'project-lab', resourceType: 'room', day: 'Sat', period: 'P2' },
  { resourceId: 'dl-gpu-lab', resourceType: 'room', day: 'Mon', period: 'P1' },
];

export const buildSchedulingProblem = (): SchedulingProblem => {
  const activities: Activity[] = [];

  for (const offering of OFFERINGS) {
    const hall = DIVISION_HALL[offering.division];

    for (let s = 1; s <= offering.theorySessions; s++) {
      activities.push({
        id: `${offering.division}-${offering.courseCode}-T${s}`,
        courseCode: offering.courseCode,
        courseTitle: offering.courseTitle,
        facultyIds: offering.facultyIds,
        groupId: `div-${offering.division}`,
        duration: 1,
        sessionType: 'theory',
        allowedRoomIds: [hall],
      });
    }

    offering.labs.forEach((lab, idx) => {
      activities.push({
        id: `${offering.division}-${offering.courseCode}-L${idx + 1}`,
        courseCode: offering.courseCode,
        courseTitle: `${offering.courseTitle} Lab`,
        facultyIds: lab.facultyIds,
        groupId: lab.groupId,
        duration: lab.duration,
        sessionType: lab.sessionType ?? 'lab',
        allowedRoomIds: lab.roomIds,
      });
    });

    if (offering.miniProject) {
      activities.push({
        id: `${offering.division}-${offering.courseCode}-MP`,
        courseCode: offering.courseCode,
        courseTitle: offering.courseTitle,
        facultyIds: offering.miniProject.facultyIds,
        groupId: `div-${offering.division}`,
        duration: offering.miniProject.duration,
        sessionType: 'project',
        allowedRoomIds: [offering.miniProject.roomId],
      });
    }
  }

  const facultyAvailability = new Map<string, Map<string, boolean>>();
  for (const f of FACULTY) {
    const map = new Map<string, boolean>();
    for (const day of DAYS) {
      for (const slot of TIME_SLOTS) {
        map.set(`${day}:${slot.id}`, !f.unavailableSlots.includes(`${day}:${slot.id}`));
      }
    }
    facultyAvailability.set(f.id, map);
  }

  const facultyPreferences = new Map<string, Set<string>>();
  for (const f of FACULTY) {
    facultyPreferences.set(f.id, new Set(f.preferredSlots));
  }

  return {
    days: DAYS,
    slots: TIME_SLOTS,
    rooms: ROOMS,
    faculty: FACULTY,
    groups: STUDENT_GROUPS,
    activities,
    facultyAvailability,
    facultyPreferences,
    unavailability: UNAVAILABILITY,
  };
};
