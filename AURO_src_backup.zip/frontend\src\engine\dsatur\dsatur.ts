import { ConflictGraph } from '../graph/ConflictGraph';
import { PriorityQueue } from '../core/priorityQueue';

export interface DsaturResult {
  order: string[];
  provisionalColors: Map<string, number>;
  trace: Array<{ step: number; activityId: string; saturation: number; degree: number; color: number }>;
}

/**
 * DSATUR (Degree of SAturation) graph-colouring heuristic.
 * Selects the most constrained activity first: highest saturation degree,
 * tie-break on highest vertex degree, then deterministic id order.
 * Colours are provisional time-block estimates that guide the CSP solver's
 * variable selection — real assignments happen during backtracking.
 */
export const runDsatur = (graph: ConflictGraph): DsaturResult => {
  const ids = Array.from(graph.vertices.keys()).sort();
  const saturation: Map<string, Set<number>> = new Map();
  const colors: Map<string, number> = new Map();
  const version: Map<string, number> = new Map();
  const trace: DsaturResult['trace'] = [];

  ids.forEach((id) => {
    saturation.set(id, new Set());
    version.set(id, 0);
  });

  const priorityOf = (id: string): number[] => [
    -saturation.get(id)!.size,
    -graph.getDegree(id),
    -asciiSum(id),
    version.get(id)!,
  ];

  let pq = new PriorityQueue<string>();
  ids.forEach((id) => pq.push(id, priorityOf(id)));

  const refresh = (id: string) => {
    version.set(id, version.get(id)! + 1);
    pq.push(id, priorityOf(id));
  };

  let step = 0;
  while (colors.size < ids.length) {
    let chosen: string | undefined;
    while (pq.size > 0) {
      const entry = pq.pop()!;
      const id = entry.item;
      const expected = priorityOf(id);
      const isFresh = entry.priority.every((v, i) => v === expected[i]);
      if (isFresh) {
        chosen = id;
        break;
      }
    }
    if (!chosen) break;

    const color = smallestAvailableColor(graph, chosen, colors);
    colors.set(chosen, color);
    trace.push({
      step: step++,
      activityId: chosen,
      saturation: saturation.get(chosen)!.size,
      degree: graph.getDegree(chosen),
      color,
    });

    for (const neighbor of graph.getNeighbors(chosen)) {
      if (!colors.has(neighbor)) {
        saturation.get(neighbor)!.add(color);
        refresh(neighbor);
      }
    }
  }

  const order = trace.map((t) => t.activityId);
  return { order, provisionalColors: colors, trace };
};

const smallestAvailableColor = (graph: ConflictGraph, id: string, colors: Map<string, number>): number => {
  const used = new Set<number>();
  for (const n of graph.getNeighbors(id)) {
    const c = colors.get(n);
    if (c !== undefined) used.add(c);
  }
  let c = 0;
  while (used.has(c)) c++;
  return c;
};

const asciiSum = (id: string): number => {
  let s = 0;
  for (let i = 0; i < id.length; i++) s += id.charCodeAt(i);
  return s;
};
