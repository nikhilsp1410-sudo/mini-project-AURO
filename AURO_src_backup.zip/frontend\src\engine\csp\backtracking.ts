import { ConflictGraph } from '../graph/ConflictGraph';
import { ResourceRegistry } from '../core/registry';
import { Assignment, DomainValue, SchedulingProblem } from '../core/types';
import { assign, createState, unassign, valueConflicts, SolverState } from './constraints';

export interface SolveMetrics {
  iterations: number;
  backtracks: number;
  prunes: number;
  maxDepth: number;
}

export interface SolveResult {
  assignments: Assignment[] | null;
  metrics: SolveMetrics;
}

const MAX_ITERATIONS = 400000;

export const solveWithBacktracking = (
  problem: SchedulingProblem,
  order: string[],
  domainsTemplate: Map<string, DomainValue[]>,
  graph: ConflictGraph,
  registry: ResourceRegistry
): SolveResult => {
  const domains: Map<string, DomainValue[]> = new Map();
  order.forEach((id) => domains.set(id, [...(domainsTemplate.get(id) ?? [])]));

  const state: SolverState = createState();
  const assignment: Map<string, DomainValue> = new Map();
  const result: Assignment[] = [];
  const metrics: SolveMetrics = { iterations: 0, backtracks: 0, prunes: 0, maxDepth: 0 };

  const orderIndex = new Map<string, number>();
  order.forEach((id, idx) => orderIndex.set(id, idx));

  const overlappingGroups = (groupId: string): string[] => {
    const group = registry.groups.get(groupId);
    if (!group) return [groupId];
    const result: string[] = [];
    for (const g of registry.groups.values()) {
      const overlaps =
        g.id === groupId ||
        (g.division === group.division && (g.batch === 'FULL' || group.batch === 'FULL' || g.batch === group.batch));
      if (overlaps) result.push(g.id);
    }
    return result;
  };

  const groupOverlapCache = new Map<string, string[]>();
  const groupsFor = (groupId: string): string[] => {
    if (!groupOverlapCache.has(groupId)) groupOverlapCache.set(groupId, overlappingGroups(groupId));
    return groupOverlapCache.get(groupId)!;
  };

  const groupsOverlap = (idA: string, idB: string): boolean => {
    if (idA === idB) return true;
    const a = registry.groups.get(idA);
    const b = registry.groups.get(idB);
    if (!a || !b) return false;
    return a.division === b.division && (a.batch === 'FULL' || b.batch === 'FULL' || a.batch === b.batch);
  };

  const domainValueSort = (a: DomainValue, b: DomainValue): number => {
    const dayDiff = problem.days.indexOf(a.day) - problem.days.indexOf(b.day);
    if (dayDiff !== 0) return dayDiff;
    const aIdx = problem.slots.find((s) => s.id === a.start)!.index;
    const bIdx = problem.slots.find((s) => s.id === b.start)!.index;
    return aIdx - bIdx;
  };

  const backtrack = (depth: number): boolean => {
    if (assignment.size === order.length) return true;
    if (metrics.iterations > MAX_ITERATIONS) return false;
    metrics.iterations += 1;
    metrics.maxDepth = Math.max(metrics.maxDepth, depth);

    let current: string | undefined;
    let bestFeasibility = Infinity;
    for (const id of order) {
      if (assignment.has(id)) continue;
      const feasibleCount = domains.get(id)!.length;
      if (feasibleCount < bestFeasibility) {
        bestFeasibility = feasibleCount;
        current = id;
        if (feasibleCount === 0) break;
      }
    }
    if (!current) return false;

    const activity = registry.getActivity(current)!;
    const values = domains.get(current)!.slice().sort(domainValueSort);

    for (const value of values) {
      metrics.iterations += 1;
      if (metrics.iterations > MAX_ITERATIONS) return false;

      if (valueConflicts(state, value, activity.facultyIds, activity.groupId, groupsFor(activity.groupId))) continue;

      assign(state, value, activity.facultyIds, activity.groupId);
      assignment.set(current, value);

      const savedDomains: Array<{ id: string; values: DomainValue[] }> = [];
      let feasible = true;

      for (const neighbor of graph.getNeighbors(current)) {
        if (assignment.has(neighbor)) continue;
        const neighborActivity = registry.getActivity(neighbor)!;
        const sharesFaculty = activity.facultyIds.some((f) => neighborActivity.facultyIds.includes(f));
        const sharesGroup = groupsOverlap(activity.groupId, neighborActivity.groupId);

        const before = domains.get(neighbor)!;
        const after = before.filter((v) => {
          if (v.day !== value.day) return true;
          if (!v.periods.some((p) => value.periods.includes(p))) return true;
          if (v.roomId === value.roomId) return false;
          if (sharesFaculty) return false;
          if (sharesGroup) return false;
          return true;
        });
        if (after.length !== before.length) {
          savedDomains.push({ id: neighbor, values: before });
          domains.set(neighbor, after);
          if (after.length === 0) {
            feasible = false;
            break;
          }
        }
      }

      if (feasible && backtrack(depth + 1)) {
        return true;
      }

      assignment.delete(current);
      unassign(state, value, activity.facultyIds, activity.groupId);
      for (const saved of savedDomains) domains.set(saved.id, saved.values);
      if (savedDomains.length > 0) metrics.prunes += 1;
      metrics.backtracks += 1;

      if (metrics.iterations > MAX_ITERATIONS) return false;
    }

    return false;
  };

  const solved = backtrack(0);

  if (solved) {
    const orderedResult: Assignment[] = [];
    for (const [activityId, value] of assignment) {
      orderedResult.push({
        activityId,
        day: value.day,
        start: value.start,
        roomId: value.roomId,
        periods: value.periods,
      });
    }
    result.push(...orderedResult);
  }

  return {
    assignments: solved ? result : null,
    metrics: {
      ...metrics,
      maxDepth: Math.min(metrics.maxDepth, order.length),
    },
  };
};
