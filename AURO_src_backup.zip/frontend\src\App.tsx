import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LoginPage } from './pages/LoginPage';
import { Navbar } from './components/Navbar';
import { Sidebar, NavTab } from './components/Sidebar';
import { OverviewPage } from './pages/dashboard/OverviewPage';
import { GeneratorPage } from './pages/dashboard/GeneratorPage';
import { ReferencePage } from './pages/dashboard/ReferencePage';

const MainLayout: React.FC = () => {
  const { user, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<NavTab>('overview');

  if (isLoading) {
    return (
      <div className="min-h-screen bg-paper flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-[3px] border-stone-200 border-t-brand-700 rounded-full animate-spin mx-auto" />
          <div className="text-xs font-semibold text-stone-500 font-mono">
            Initializing AURO Orchestration Engine…
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginPage />;
  }

  return (
    <div className="min-h-screen bg-paper flex">
      <Sidebar active={activeTab} onNavigate={setActiveTab} />
      <div className="flex-1 min-w-0">
        <Navbar />
        <div className="lg:hidden px-4 pt-3 flex gap-2 overflow-x-auto">
          {(
            [
              { id: 'overview', label: 'Command Center' },
              { id: 'generator', label: 'Timetable Engine' },
              { id: 'reference', label: 'Reference' },
            ] as Array<{ id: NavTab; label: string }>
          ).map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap border transition-colors cursor-pointer ${
                activeTab === t.id
                  ? 'bg-brand-700 text-white border-brand-700'
                  : 'bg-white text-stone-600 border-stone-200'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
        {activeTab === 'overview' && <OverviewPage onOpenEngine={() => setActiveTab('generator')} />}
        {activeTab === 'generator' && <GeneratorPage />}
        {activeTab === 'reference' && <ReferencePage />}
      </div>
    </div>
  );
};

export function App() {
  return (
    <AuthProvider>
      <MainLayout />
    </AuthProvider>
  );
}

export default App;
