"""
Core domain types for the AURO DSA timetable-generation engine.

Time model: 6 days (Mon-Sat) x 8 periods. Blocks are contiguous runs of
periods; PERIOD_BLOCK_STARTS restricts which starting periods are legal
for each block duration (e.g. 3-hour labs may only start at P5).
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

Day = str        # 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat'
PeriodId = str   # 'P1' .. 'P8'
Division = str   # 'A' | 'B' | 'C' | 'D'
BatchId = str    # 'FULL' | 'B1' | 'B2'
SessionType = str  # 'theory' | 'lab' | 'project'


@dataclass
class TimeSlot:
    id: PeriodId
    index: int
    start: str
    end: str
    label: str


@dataclass
class Room:
    id: str
    name: str
    type: str          # 'lecture-hall' | 'laboratory'
    capacity: int
    building: str


@dataclass
class Faculty:
    id: str
    name: str
    designation: str
    unavailable_slots: List[str] = field(default_factory=list)  # 'Mon:P3' keys
    preferred_slots: List[str] = field(default_factory=list)


@dataclass
class StudentGroup:
    id: str
    division: Division
    batch: BatchId
    size: int


@dataclass
class Activity:
    """A single schedulable session (one vertex of the conflict graph)."""
    id: str
    course_code: str
    course_title: str
    faculty_ids: List[str]
    group_id: str
    duration: int                      # hours (1-4)
    session_type: SessionType
    allowed_room_ids: List[str]


@dataclass
class DomainValue:
    """One feasible placement candidate: (day, start period, room)."""
    day: Day
    start: PeriodId
    room_id: str
    periods: List[PeriodId]


@dataclass
class Assignment:
    activity_id: str
    day: Day
    start: PeriodId
    room_id: str
    periods: List[PeriodId]


@dataclass
class Unavailability:
    resource_id: str
    resource_type: str  # 'faculty' | 'room'
    day: Day
    period: PeriodId


@dataclass
class SchedulingProblem:
    days: List[Day]
    slots: List[TimeSlot]
    rooms: List[Room]
    faculty: List[Faculty]
    groups: List[StudentGroup]
    activities: List[Activity]
    faculty_availability: Dict[str, Dict[str, bool]]
    faculty_preferences: Dict[str, Set[str]]
    unavailability: List[Unavailability]


PERIOD_BLOCK_STARTS: Dict[int, List[PeriodId]] = {
    1: ["P1", "P2", "P3", "P4", "P5", "P6", "P7"],
    2: ["P1", "P3", "P5"],
    3: ["P5"],
    4: ["P5"],
}
