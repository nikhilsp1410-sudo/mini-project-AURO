import React, { useMemo, useState } from 'react';
import {
  Brain,
  Play,
  Loader2,
  CheckCircle2,
  XCircle,
  GitBranch,
  Network,
  Shuffle,
  ListChecks,
  Gauge,
  Timer,
  Undo2,
  Scissors,
  Layers,
} from 'lucide-react';
import { buildSchedulingProblem, DAYS, TIME_SLOTS } from '../../data/curriculum';
import { generateTimetable, GenerationResult, Division, Activity, Assignment } from '../../engine';

type DivisionFilter = 'ALL' | Division;

const PIPELINE_STEPS = [
  { label: 'Conflict Graph', icon: GitBranch },
  { label: 'DSATUR Ordering', icon: Shuffle },
  { label: 'CSP Domains', icon: Network },
  { label: 'Backtracking + FC', icon: Brain },
  { label: 'Hard Validation', icon: ListChecks },
  { label: 'Soft Scoring', icon: Gauge },
];

const PERIOD_ROW_LABELS: Array<{ label: string; start: string; isBreak?: boolean }> = [
  { label: '08:00 – 09:00', start: 'P1' },
  { label: '09:00 – 10:00', start: 'P2' },
  { label: 'BREAK · 10:00 – 10:30', start: '', isBreak: true },
  { label: '10:30 – 11:30', start: 'P3' },
  { label: '11:30 – 12:30', start: 'P4' },
  { label: 'LUNCH · 12:30 – 01:30', start: '', isBreak: true },
  { label: '01:30 – 02:30', start: 'P5' },
  { label: '02:30 – 03:30', start: 'P6' },
  { label: '03:30 – 04:30', start: 'P7' },
  { label: '04:30 – 05:30', start: 'P8' },
];

const typeTone = (type: string) => {
  switch (type) {
    case 'theory':
      return 'text-blue-700 bg-blue-50/80 border-blue-200';
    case 'lab':
      return 'text-purple-700 bg-purple-50/80 border-purple-200';
    case 'project':
      return 'text-amber-800 bg-amber-50/80 border-amber-200';
    default:
      return 'text-emerald-700 bg-emerald-50/80 border-emerald-200';
  }
};

const StatCard: React.FC<{ icon: React.ElementType; label: string; value: string | number; sub?: string }> = ({ icon: Icon, label, value, sub }) => (
  <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-2xs">
    <div className="flex items-center gap-1.5 text-[10px] font-mono font-bold tracking-widest text-stone-400 uppercase">
      <Icon className="w-3.5 h-3.5 text-brand-700" />
      {label}
    </div>
    <div className="font-serif text-xl font-black text-stone-900 mt-1.5">{value}</div>
    {sub && <div className="text-[10px] font-mono text-stone-400 mt-0.5">{sub}</div>}
  </div>
);

const DivisionGrid: React.FC<{
  division: Division;
  assignments: Assignment[];
  activityById: Map<string, Activity>;
}> = ({ division, assignments, activityById }) => {
  const divisionAssignments = useMemo(
    () =>
      assignments.filter((a) => {
        const act = activityById.get(a.activityId);
        return act?.groupId.startsWith(`div-${division}`) || act?.groupId === `div-${division}`;
      }),
    [assignments, division, activityById]
  );

  const coveringAssignment = (day: string, periodId: string): Assignment | null => {
    const thisIdx = TIME_SLOTS.find((s) => s.id === periodId)!.index;
    for (const a of divisionAssignments) {
      if (a.day !== day) continue;
      const act = activityById.get(a.activityId)!;
      const startIdx = TIME_SLOTS.find((s) => s.id === a.start)!.index;
      const endIdx = startIdx + act.duration - 1;
      if (thisIdx >= startIdx && thisIdx <= endIdx) return a;
    }
    return null;
  };

  return (
    <div className="rounded-2xl border border-stone-300 bg-[#FDFBF6] shadow-sm overflow-hidden">
      <div className="px-5 py-3 border-b border-stone-200 flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="font-mono text-[10px] font-bold tracking-[0.2em] text-brand-700">
            GENERATED · DIVISION {division}
          </div>
          <div className="text-[11px] text-stone-500 font-medium mt-0.5">
            B.E. CSE Semester V · 2026–27 · AURO DSA Engine output
          </div>
        </div>
        <span className="text-[9px] font-mono tracking-widest text-stone-400 border border-stone-200 rounded-full px-2.5 py-1">
          HARD-CONSTRAINT VALID
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-[10px]" style={{ minWidth: 720 }}>
          <thead>
            <tr className="bg-stone-50 border-b border-stone-200">
              <th className="px-3 py-2 text-left font-mono text-[9px] font-bold tracking-widest text-stone-500 border-r border-stone-200 w-[110px]">
                PERIOD
              </th>
              {DAYS.map((d) => (
                <th key={d} className="px-2 py-2 text-center font-mono text-[9.5px] font-bold tracking-widest text-stone-600">
                  {d.toUpperCase()}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {PERIOD_ROW_LABELS.map((row) => (
              <tr key={row.label} className="border-b border-stone-100">
                <td className={`px-3 py-1.5 border-r border-stone-200 font-mono text-[9.5px] font-bold whitespace-nowrap align-middle ${row.isBreak ? 'text-stone-400 bg-stone-50/80 tracking-[0.2em]' : 'text-stone-600'}`}>
                  {row.label}
                </td>
                {row.isBreak ? (
                  <td colSpan={6} className="px-3 py-1 text-center font-mono text-[9px] tracking-[0.3em] text-stone-300 bg-stone-50/50" />
                ) : (
                  DAYS.map((day) => {
                    const covering = coveringAssignment(day, row.start);
                    if (!covering) {
                      return (
                        <td key={day} className="px-1.5 py-1 align-top border-r border-stone-100 last:border-r-0">
                          <div className="h-[26px] flex items-center justify-center text-stone-300">·</div>
                        </td>
                      );
                    }
                    const act = activityById.get(covering.activityId)!;
                    if (covering.start !== row.start) {
                      return null;
                    }
                    return (
                      <td
                        key={day}
                        rowSpan={act.duration}
                        className="px-1.5 py-1 align-top border-r border-stone-100 last:border-r-0"
                      >
                        <div
                          className={`h-full px-1.5 py-1 rounded border ${typeTone(act.sessionType)} leading-tight`}
                          title={`${act.courseTitle} · ${act.sessionType} · ${act.duration}h`}
                        >
                          <div className="font-mono font-bold text-[9px] truncate">{act.courseCode}</div>
                          <div className="text-[8.5px] font-mono text-stone-500 truncate">{covering.roomId}</div>
                          <div className="text-[8.5px] font-mono text-stone-400">{act.duration}h block</div>
                        </div>
                      </td>
                    );
                  })
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export const GeneratorPage: React.FC = () => {
  const [divisionFilter, setDivisionFilter] = useState<DivisionFilter>('ALL');
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<GenerationResult | null>(null);
  const [activeStep, setActiveStep] = useState(-1);

  const problem = useMemo(() => buildSchedulingProblem(), []);
  const activityById = useMemo(() => new Map(problem.activities.map((a) => [a.id, a])), [problem]);

  const visibleAssignments = useMemo(() => {
    if (!result) return [];
    if (divisionFilter === 'ALL') return result.assignments;
    return result.assignments.filter((a) => {
      const act = activityById.get(a.activityId);
      return act?.groupId.startsWith(`div-${divisionFilter}`);
    });
  }, [result, divisionFilter, activityById]);

  const divisionsToShow = useMemo(() => {
    if (divisionFilter === 'ALL') return (['A', 'B', 'C', 'D'] as Division[]);
    return [divisionFilter];
  }, [divisionFilter]);

  const runGeneration = () => {
    setRunning(true);
    setResult(null);
    setActiveStep(0);

    let step = 0;
    const stepTimer = setInterval(() => {
      step += 1;
      setActiveStep(step);
      if (step >= PIPELINE_STEPS.length - 1) clearInterval(stepTimer);
    }, 160);

    setTimeout(() => {
      clearInterval(stepTimer);
      const generated = generateTimetable(problem);
      setResult(generated);
      setActiveStep(PIPELINE_STEPS.length);
      setRunning(false);
    }, 900);
  };

  const hardAllPassed = result ? result.hardValidation.every((c) => c.passed) : false;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header + controls */}
      <div className="rounded-2xl border border-stone-300 bg-[#FDFBF6] p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="font-mono text-[10px] font-bold tracking-[0.25em] text-brand-700">
              DSA ENGINE · MODE A · INITIAL TIMETABLE GENERATION
            </div>
            <h1 className="font-serif text-2xl font-black tracking-tight text-stone-900 mt-1.5">
              Timetable Creation Pipeline
            </h1>
            <p className="text-xs text-stone-500 mt-1.5 max-w-xl">
              Runs the full DSA pipeline over live curriculum data — conflict graph construction,
              DSATUR ordering, CSP domain building, backtracking with forward checking, then hard
              validation and soft scoring.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-lg border border-stone-200">
              {(['ALL', 'A', 'B', 'C', 'D'] as DivisionFilter[]).map((d) => (
                <button
                  key={d}
                  onClick={() => setDivisionFilter(d)}
                  className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer ${
                    divisionFilter === d ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-500 hover:text-stone-800'
                  }`}
                >
                  {d === 'ALL' ? 'All Divisions' : `Div ${d}`}
                </button>
              ))}
            </div>
            <button
              onClick={runGeneration}
              disabled={running}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-brand-700 to-brand-800 text-white text-xs font-bold tracking-wide shadow-sm hover:shadow-md hover:-translate-y-px transition-all disabled:opacity-80 disabled:cursor-not-allowed cursor-pointer"
            >
              {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
              {running ? 'ORCHESTRATING…' : 'GENERATE TIMETABLE'}
            </button>
          </div>
        </div>

        {/* Pipeline stepper */}
        <div className="flex flex-wrap items-center gap-1.5 mt-5 pt-4 border-t border-stone-200">
          {PIPELINE_STEPS.map((step, i) => {
            const Icon = step.icon;
            const isDone = result ? activeStep > i : activeStep > i;
            const isActive = running && activeStep === i;
            return (
              <React.Fragment key={step.label}>
                <span
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-mono font-bold border transition-colors ${
                    isDone
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      : isActive
                      ? 'bg-brand-50 text-brand-700 border-brand-300'
                      : 'bg-stone-50 text-stone-400 border-stone-200'
                  }`}
                >
                  {isDone ? <CheckCircle2 className="w-3 h-3" /> : <Icon className="w-3 h-3" />}
                  {step.label.toUpperCase()}
                </span>
                {i < PIPELINE_STEPS.length - 1 && <span className="text-stone-300 text-[10px]">→</span>}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {/* Empty state */}
      {!result && !running && (
        <div className="rounded-2xl border border-dashed border-stone-300 bg-white/60 p-14 text-center">
          <Brain className="w-10 h-10 text-stone-300 mx-auto" />
          <div className="font-serif font-bold text-stone-700 mt-3">No schedule generated yet</div>
          <p className="text-xs text-stone-400 mt-1">
            Press <span className="font-mono font-bold text-brand-700">GENERATE TIMETABLE</span> to run the DSA engine across {problem.activities.length} activities.
          </p>
        </div>
      )}

      {running && !result && (
        <div className="rounded-2xl border border-stone-200 bg-white p-14 text-center">
          <Loader2 className="w-8 h-8 text-brand-700 animate-spin mx-auto" />
          <div className="text-xs font-mono font-bold tracking-widest text-stone-500 mt-3">
            RUNNING DSATUR + CSP SEARCH OVER {problem.activities.length} ACTIVITIES…
          </div>
        </div>
      )}

      {/* Results */}
      {result && (
        <>
          {/* Failure banner */}
          {!result.metrics.solved && (
            <div className="rounded-2xl border border-rose-300 bg-rose-50 p-5">
              <div className="flex items-center gap-2 text-rose-800 font-bold text-sm">
                <XCircle className="w-5 h-5" />
                No feasible timetable found within the iteration budget
              </div>
              <p className="text-xs text-rose-700 mt-1.5">
                AURO reports unresolved conflicts rather than emitting an invalid schedule. Raise the
                search budget or relax faculty unavailability windows.
              </p>
            </div>
          )}

          {/* Conflict graph + search metrics */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-serif text-lg font-black text-stone-900">Engine Telemetry</h2>
              <span className="text-[10px] font-mono tracking-widest text-stone-400">
                SOLVED IN {result.metrics.elapsedMs} MS · {result.generatedAt}
              </span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
              <StatCard icon={GitBranch} label="Vertices" value={result.metrics.vertices} sub="scheduling activities" />
              <StatCard icon={Network} label="Edges" value={result.metrics.edges} sub={`density ${result.metrics.graphDensity}`} />
              <StatCard icon={Layers} label="Max Degree" value={result.metrics.maxDegree} sub={`avg ${result.metrics.averageDegree}`} />
              <StatCard icon={Timer} label="Iterations" value={result.metrics.iterations.toLocaleString()} sub="CSP search nodes" />
              <StatCard icon={Undo2} label="Backtracks" value={result.metrics.backtracks.toLocaleString()} sub="state restorations" />
              <StatCard icon={Scissors} label="FC Prunes" value={result.metrics.prunes.toLocaleString()} sub={`max depth ${result.metrics.maxDepth}`} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-2xs">
                <div className="text-[10px] font-mono font-bold tracking-widest text-stone-400 uppercase">
                  Conflict edges by shared resource
                </div>
                <div className="grid grid-cols-3 gap-3 mt-3">
                  {(
                    [
                      ['Faculty', result.metrics.edgesByReason.faculty],
                      ['Student group', result.metrics.edgesByReason.group],
                      ['Room rivalry', result.metrics.edgesByReason.room],
                    ] as Array<[string, number]>
                  ).map(([label, count]) => {
                    const pct = result.metrics.edges > 0 ? Math.round((count / result.metrics.edges) * 100) : 0;
                    return (
                      <div key={label} className="rounded-lg bg-stone-50 border border-stone-100 p-3">
                        <div className="text-[10px] font-bold text-stone-500">{label}</div>
                        <div className="font-serif text-lg font-black text-stone-900">{count}</div>
                        <div className="h-1.5 rounded-full bg-stone-200 mt-1.5 overflow-hidden">
                          <div className="h-full bg-brand-600 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-2xs">
                <div className="text-[10px] font-mono font-bold tracking-widest text-stone-400 uppercase">
                  DSATUR ordering trace · first 12
                </div>
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {result.metrics.dsaturOrderFirst.map((id, i) => {
                    const act = activityById.get(id);
                    return (
                      <span
                        key={id}
                        className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-stone-50 border border-stone-200 text-[9.5px] font-mono font-bold text-stone-600"
                        title={act ? `${act.courseTitle} · deg ${''}` : id}
                      >
                        <span className="text-brand-700">{i + 1}</span>
                        {id}
                      </span>
                    );
                  })}
                </div>
                <p className="text-[10px] text-stone-400 mt-3 leading-relaxed">
                  Highest saturation & degree first — the most constrained activities get scheduled
                  earliest, improving search success.
                </p>
              </div>
            </div>
          </div>

          {/* Hard constraint validation */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-serif text-lg font-black text-stone-900">Hard Constraint Validation</h2>
              <span
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-mono font-bold tracking-widest border ${
                  hardAllPassed
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-rose-50 text-rose-700 border-rose-200'
                }`}
              >
                {hardAllPassed ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                {hardAllPassed ? 'ALL 7 CONSTRAINTS PASS' : 'VIOLATIONS DETECTED'}
              </span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {result.hardValidation.map((check) => (
                <div
                  key={check.id}
                  className={`rounded-xl border p-4 ${check.passed ? 'bg-emerald-50/60 border-emerald-200' : 'bg-rose-50 border-rose-200'}`}
                >
                  <div className="flex items-center gap-2">
                    {check.passed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    )}
                    <span className="text-xs font-bold text-stone-800">
                      <span className="font-mono text-stone-500 mr-1.5">{check.id}</span>
                      {check.label}
                    </span>
                  </div>
                  {!check.passed && check.violations.length > 0 && (
                    <ul className="mt-2 space-y-1 pl-6">
                      {check.violations.slice(0, 4).map((v, i) => (
                        <li key={i} className="text-[10.5px] font-mono text-rose-700">{v}</li>
                      ))}
                      {check.violations.length > 4 && (
                        <li className="text-[10px] text-rose-500 font-bold">+{check.violations.length - 4} more</li>
                      )}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Soft score */}
          <div className="space-y-3">
            <h2 className="font-serif text-lg font-black text-stone-900">Soft Constraint Optimisation</h2>
            <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-2xs grid grid-cols-2 lg:grid-cols-4 gap-4">
              {(
                [
                  ['Faculty preference hit', `${result.softScore.facultyPreference}%`, 'preferred slots honoured', 100],
                  ['Idle gaps (penalty)', `${result.softScore.gapPenalty}`, 'total free periods between faculty classes', 40],
                  ['Load imbalance', `${result.softScore.loadBalance}`, 'daily-load variance per faculty', 20],
                  ['Room utilisation', `${result.softScore.roomUtilization}%`, 'batch seats vs room capacity', 100],
                ] as Array<[string, string, string, number]>
              ).map(([label, value, sub, max]) => {
                const numeric = parseFloat(value);
                const pct = Math.max(0, Math.min(100, (numeric / max) * 100));
                return (
                  <div key={label}>
                    <div className="text-[10px] font-mono font-bold tracking-widest text-stone-400 uppercase">{label}</div>
                    <div className="font-serif text-xl font-black text-stone-900 mt-1">{value}</div>
                    <div className="h-1.5 rounded-full bg-stone-100 mt-2 overflow-hidden">
                      <div className="h-full bg-brand-600 rounded-full" style={{ width: `${pct}%` }} />
                    </div>
                    <div className="text-[9.5px] text-stone-400 mt-1.5 font-medium">{sub}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Generated timetables */}
          <div className="space-y-4">
            <h2 className="font-serif text-lg font-black text-stone-900">Generated Weekly Timetables</h2>
            {divisionsToShow.map((div) => (
              <DivisionGrid
                key={div}
                division={div}
                assignments={visibleAssignments}
                activityById={activityById}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
};
