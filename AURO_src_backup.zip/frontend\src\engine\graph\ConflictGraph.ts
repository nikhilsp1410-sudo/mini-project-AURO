import { Activity } from '../core/types';

export type ConflictReason = 'faculty' | 'group' | 'room';

const edgeKey = (u: string, v: string): string => (u < v ? `${u}|${v}` : `${v}|${u}`);

export class ConflictGraph {
  readonly vertices: Map<string, Activity> = new Map();
  readonly adjacency: Map<string, Set<string>> = new Map();
  private edgeReasons: Map<string, Set<ConflictReason>> = new Map();

  addVertex(activity: Activity): void {
    if (this.vertices.has(activity.id)) return;
    this.vertices.set(activity.id, activity);
    this.adjacency.set(activity.id, new Set());
  }

  addEdge(u: string, v: string, reason: ConflictReason): void {
    if (u === v) return;
    if (!this.adjacency.has(u) || !this.adjacency.has(v)) return;
    this.adjacency.get(u)!.add(v);
    this.adjacency.get(v)!.add(u);
    const key = edgeKey(u, v);
    if (!this.edgeReasons.has(key)) this.edgeReasons.set(key, new Set());
    this.edgeReasons.get(key)!.add(reason);
  }

  removeVertex(id: string): void {
    const neighbors = this.adjacency.get(id);
    if (neighbors) {
      for (const n of neighbors) this.adjacency.get(n)?.delete(id);
    }
    this.adjacency.delete(id);
    this.vertices.delete(id);
  }

  removeEdge(u: string, v: string): void {
    this.adjacency.get(u)?.delete(v);
    this.adjacency.get(v)?.delete(u);
    this.edgeReasons.delete(edgeKey(u, v));
  }

  getNeighbors(id: string): Set<string> {
    return this.adjacency.get(id) ?? new Set();
  }

  getDegree(id: string): number {
    return this.adjacency.get(id)?.size ?? 0;
  }

  isAdjacent(u: string, v: string): boolean {
    return this.adjacency.get(u)?.has(v) ?? false;
  }

  getConflictInfo(u: string, v: string): ConflictReason[] {
    return Array.from(this.edgeReasons.get(edgeKey(u, v)) ?? []);
  }

  get edgeCount(): number {
    return this.edgeReasons.size;
  }

  get edgesByReason(): { faculty: number; group: number; room: number } {
    const counts = { faculty: 0, group: 0, room: 0 };
    for (const reasons of this.edgeReasons.values()) {
      if (reasons.has('faculty')) counts.faculty += 1;
      if (reasons.has('group')) counts.group += 1;
      if (reasons.has('room')) counts.room += 1;
    }
    return counts;
  }

  static build(activities: Activity[]): ConflictGraph {
    const graph = new ConflictGraph();
    activities.forEach((a) => graph.addVertex(a));

    for (let i = 0; i < activities.length; i++) {
      for (let j = i + 1; j < activities.length; j++) {
        const a = activities[i];
        const b = activities[j];

        const sharesFaculty = a.facultyIds.some((f) => b.facultyIds.includes(f));
        if (sharesFaculty) graph.addEdge(a.id, b.id, 'faculty');

        const sharesGroup = a.groupId === b.groupId;
        if (sharesGroup) graph.addEdge(a.id, b.id, 'group');

        const sharesRoom = a.allowedRoomIds.some((r) => b.allowedRoomIds.includes(r));
        if (sharesRoom) graph.addEdge(a.id, b.id, 'room');
      }
    }
    return graph;
  }
}
