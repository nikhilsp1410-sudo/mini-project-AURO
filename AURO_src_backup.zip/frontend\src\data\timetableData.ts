export interface ScheduleEntry {
  id: string;
  day: 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat';
  time: string; // e.g. "08:00 - 09:00"
  duration: number; // in hours (1, 2, 3, 4)
  code: string;
  subject: string;
  faculty: string;
  room: string;
  building: string;
  type: 'theory' | 'lab' | 'project' | 'training';
  batch?: string; // e.g. "Batch 1 (1 to 60)"
  division: 'A' | 'B' | 'C' | 'D';
}

export interface CourseInfo {
  code: string;
  title: string;
  credits: number;
  type: 'Integrated' | 'Theory' | 'Practical' | 'Project' | 'Audit';
  faculty: string;
  syllabusSummary: string;
  ltps: string; // Lecture-Tutorial-Practical-SelfStudy
}

export interface VenueInfo {
  code: string;
  name: string;
  type: 'Lecture Hall' | 'Laboratory' | 'Seminar Hall';
  location: string;
  capacity: number;
  features: string[];
  inCharge: string;
}

export interface FacultyMember {
  id: string;
  name: string;
  designation: string;
  department: string;
  cabin: string;
  email: string;
  phoneExt: string;
  specialization: string;
  coursesHandled: string[];
}

export interface DepartmentNotice {
  id: string;
  title: string;
  date: string;
  category: 'Timetable' | 'Examination' | 'Project' | 'General';
  author: string;
  content: string;
  priority: 'high' | 'normal';
}

export const TIME_PERIODS = [
  { id: 'p1', time: '08:00 - 09:00', label: 'Period 1' },
  { id: 'p2', time: '09:00 - 10:00', label: 'Period 2' },
  { id: 'break1', time: '10:00 - 10:30', label: 'Morning Break (30 min)', isBreak: true },
  { id: 'p3', time: '10:30 - 11:30', label: 'Period 3' },
  { id: 'p4', time: '11:30 - 12:30', label: 'Period 4' },
  { id: 'lunch', time: '12:30 - 01:30', label: 'Lunch Recess (60 min)', isBreak: true },
  { id: 'p5', time: '01:30 - 02:30', label: 'Period 5' },
  { id: 'p6', time: '02:30 - 03:30', label: 'Period 6' },
  { id: 'p7', time: '03:30 - 04:30', label: 'Period 7' },
  { id: 'p8', time: '04:30 - 05:30', label: 'Extended Lab Slot' },
];

export const KLE_COURSES: CourseInfo[] = [
  {
    code: '25ECSC309',
    title: 'Deep Learning',
    credits: 4,
    type: 'Integrated',
    faculty: 'Dr. Salma Shahapur / Tabassum J',
    syllabusSummary: 'Multilayer Perceptrons, CNNs, RNNs/LSTMs, Transformers, Computer Vision architectures & PyTorch implementation.',
    ltps: '3-0-2-0'
  },
  {
    code: '25ECSC304',
    title: 'Cryptography & Network Security',
    credits: 4,
    type: 'Integrated',
    faculty: 'U. V. Somanatti / Neha Nimbalkar',
    syllabusSummary: 'Symmetric/Asymmetric encryption, RSA, ECC, Hash functions, Digital signatures, TLS protocol & Network security firewalls.',
    ltps: '3-0-2-0'
  },
  {
    code: '26ECSC313',
    title: 'Microcontroller & Embedded Systems',
    credits: 4,
    type: 'Integrated',
    faculty: 'Amey Muchandi / Dr. Niranjan Muchandi',
    syllabusSummary: 'ARM Cortex M4 architecture, assembly & embedded C programming, GPIO, timers, ADC/DAC, interrupt servicing, RTOS concepts.',
    ltps: '3-0-2-0'
  },
  {
    code: '26ECSC312',
    title: 'Wireless and Mobile Networks',
    credits: 4,
    type: 'Integrated',
    faculty: 'Dr. Ryan Dias / Supriya Belkar / Madhurani S',
    syllabusSummary: 'Cellular wireless architecture, 4G LTE/5G NR radio access, Mobile IP, routing protocols in ad-hoc and sensor networks.',
    ltps: '3-0-2-0'
  },
  {
    code: '26ECSE346',
    title: 'AI Assisted Software Development',
    credits: 3,
    type: 'Practical',
    faculty: 'Dr. Santosh Pattar / Ashwini B',
    syllabusSummary: 'Prompt engineering for code generation, autonomous coding agents, LLM-based test generation, CI/CD automated review bots.',
    ltps: '1-0-4-0'
  },
  {
    code: '25ECSE347',
    title: 'Cyber Security',
    credits: 3,
    type: 'Theory',
    faculty: 'Sushmita P',
    syllabusSummary: 'Vulnerability assessment, penetration testing, malware analysis, OWASP Top 10 web application vulnerabilities, incident response.',
    ltps: '3-0-0-0'
  },
  {
    code: '25ECSW301',
    title: 'Mini Project Evaluation',
    credits: 2,
    type: 'Project',
    faculty: 'Dr. Rajashri Khanai / Sushmita P',
    syllabusSummary: 'Hands-on domain-specific system design, software development cycle, sprint demonstrations, thesis writeup & oral viva.',
    ltps: '0-0-4-0'
  },
  {
    code: '23EHSA303',
    title: 'ATAR (Soft Skills & Aptitude)',
    credits: 1,
    type: 'Audit',
    faculty: 'Priyanka Patil',
    syllabusSummary: 'Quantitative aptitude, logical reasoning, verbal communication, professional interview etiquette, corporate readiness.',
    ltps: '1-0-0-0'
  },
  {
    code: '26ECAC301',
    title: 'Cloud Computing',
    credits: 4,
    type: 'Integrated',
    faculty: 'Madhurani S',
    syllabusSummary: 'Cloud service models (IaaS, PaaS, SaaS), virtualization, AWS/GCP architecture, Kubernetes container orchestration.',
    ltps: '3-0-2-0'
  },
  {
    code: '26ECAC304',
    title: 'Parallel and GPU Computing',
    credits: 4,
    type: 'Integrated',
    faculty: 'Dr. Santosh Pattar',
    syllabusSummary: 'Heterogeneous computing, NVIDIA CUDA architecture, thread hierarchy, shared memory optimizations, OpenMP & MPI.',
    ltps: '3-0-2-0'
  }
];

export const KLE_VENUES: VenueInfo[] = [
  {
    code: 'Step Hall',
    name: 'Step Hall Lecture Complex',
    type: 'Lecture Hall',
    location: 'Main Building Block A, Ground Floor',
    capacity: 120,
    features: ['Tiered acoustic amphitheater', 'Dual high-lumen projectors', 'Smart podium', 'Air conditioned'],
    inCharge: 'Division A Class Coordinator'
  },
  {
    code: 'MB204',
    name: 'Lecture Hall MB-204',
    type: 'Lecture Hall',
    location: 'Main Building Block A, 2nd Floor',
    capacity: 90,
    features: ['Modern lecture classroom', 'Interactive smart board', 'Wired audio system'],
    inCharge: 'Division B Class Coordinator'
  },
  {
    code: 'MB208',
    name: 'Lecture Hall MB-208',
    type: 'Lecture Hall',
    location: 'Main Building Block A, 2nd Floor',
    capacity: 90,
    features: ['Natural ventilation', 'Ceiling-mounted laser projector', 'Ergonomic bench seating'],
    inCharge: 'Division C Class Coordinator'
  },
  {
    code: 'AI Room',
    name: 'AI Specialization Classroom',
    type: 'Lecture Hall',
    location: 'Computer Science Wing, 1st Floor',
    capacity: 80,
    features: ['Dedicated AI Division D setup', 'High-speed gigabit Wi-Fi 6', 'Interactive touchscreen'],
    inCharge: 'Division D Class Coordinator'
  },
  {
    code: 'Project Lab',
    name: 'Cap-Stone & Research Project Lab',
    type: 'Laboratory',
    location: 'Computer Science Wing, Ground Floor',
    capacity: 65,
    features: ['65 Intel Core i9 Dell workstations', 'GitHub enterprise sync', 'Continuous power backup'],
    inCharge: 'Dr. Santosh Pattar'
  },
  {
    code: 'Network Lab',
    name: 'Network Security & CNS Lab',
    type: 'Laboratory',
    location: 'Computer Science Wing, 1st Floor',
    capacity: 60,
    features: ['Cisco managed switches & routers', 'Wireshark packet capture rigs', 'Dedicated hardware firewalls'],
    inCharge: 'Prof. U. V. Somanatti'
  },
  {
    code: 'DL GPU Lab',
    name: 'Deep Learning & GPU Cluster Lab',
    type: 'Laboratory',
    location: 'Advanced Computing Center, Room 302',
    capacity: 50,
    features: ['NVIDIA RTX 4090 / A100 GPU compute nodes', 'PyTorch / TensorFlow Linux environment'],
    inCharge: 'Dr. Salma Shahapur'
  },
  {
    code: 'Embedded Lab',
    name: 'Embedded Systems & IoT Laboratory',
    type: 'Laboratory',
    location: 'Electronics & Computer Wing, Room 105',
    capacity: 60,
    features: ['ARM Cortex M4 evaluation kits', 'Digital storage oscilloscopes', 'Logic analyzers & sensors'],
    inCharge: 'Prof. Amey Muchandi'
  }
];

export const KLE_FACULTY: FacultyMember[] = [
  {
    id: 'f1',
    name: 'Dr. Rajashri Khanai',
    designation: 'Professor & Head of Department',
    department: 'Computer Science and Engineering',
    cabin: 'CS-101 (HOD Chamber, 1st Floor)',
    email: 'hod_cse@kletech.ac.in',
    phoneExt: 'Ext. 2401',
    specialization: 'Artificial Intelligence, Computer Networks, Curriculum Governance',
    coursesHandled: ['Mini Project Evaluation (25ECSW301)']
  },
  {
    id: 'f2',
    name: 'Dr. Praveen A. Ghorpade',
    designation: 'Professor & Dean Academics',
    department: 'Academic Affairs & CSE',
    cabin: 'Admin Block, Room 201',
    email: 'dean_acad@kletech.ac.in',
    phoneExt: 'Ext. 2105',
    specialization: 'Software Architecture, Academic Senate Affairs, Accreditation',
    coursesHandled: ['Institutional Academic Governance']
  },
  {
    id: 'f3',
    name: 'Dr. Priyanka Gavade',
    designation: 'Assistant Professor & Timetable Officer',
    department: 'Computer Science and Engineering',
    cabin: 'CS-104 (Faculty Block A)',
    email: 'priyanka.gavade@kletech.ac.in',
    phoneExt: 'Ext. 2415',
    specialization: 'Cloud Infrastructure, Data Science, Timetable Scheduling Optimization',
    coursesHandled: ['Academic Scheduling Officer', 'CSE Elective In-Charge']
  },
  {
    id: 'f4',
    name: 'Dr. Salma Shahapur',
    designation: 'Associate Professor',
    department: 'Computer Science and Engineering',
    cabin: 'CS-205 (2nd Floor Faculty Block)',
    email: 'salma.shahapur@kletech.ac.in',
    phoneExt: 'Ext. 2420',
    specialization: 'Deep Learning, Convolutional Networks, Computer Vision',
    coursesHandled: ['Deep Learning (25ECSC309)', 'Deep Learning Lab (26ECSP309)']
  },
  {
    id: 'f5',
    name: 'Dr. Santosh Pattar',
    designation: 'Associate Professor',
    department: 'Computer Science and Engineering',
    cabin: 'CS-208 (2nd Floor Faculty Block)',
    email: 'santosh.pattar@kletech.ac.in',
    phoneExt: 'Ext. 2422',
    specialization: 'Parallel and GPU Computing, AI-Assisted Software Systems',
    coursesHandled: ['AI Assisted Soft. Dev (26ECSE346)', 'Parallel & GPU Computing (26ECAC304)']
  },
  {
    id: 'f6',
    name: 'Prof. Amey Muchandi',
    designation: 'Assistant Professor',
    department: 'Computer Science and Engineering',
    cabin: 'CS-210 (2nd Floor Faculty Block)',
    email: 'amey.muchandi@kletech.ac.in',
    phoneExt: 'Ext. 2425',
    specialization: 'Microcontrollers, ARM Architecture, Real-Time Operating Systems',
    coursesHandled: ['Microcontroller & Embd Systems (26ECSC313)', 'MCES Lab', 'Mini Project (D DIV)']
  },
  {
    id: 'f7',
    name: 'Dr. Ryan Dias',
    designation: 'Assistant Professor',
    department: 'Computer Science and Engineering',
    cabin: 'CS-212 (2nd Floor Faculty Block)',
    email: 'ryan.dias@kletech.ac.in',
    phoneExt: 'Ext. 2428',
    specialization: 'Wireless and Mobile Networks, 5G Protocols, Ad-Hoc Routing',
    coursesHandled: ['Wireless and Mobile Networks (26ECSC312)', 'WMN Lab']
  },
  {
    id: 'f8',
    name: 'Prof. U. V. Somanatti',
    designation: 'Associate Professor',
    department: 'Computer Science and Engineering',
    cabin: 'CS-206 (2nd Floor Faculty Block)',
    email: 'uv.somanatti@kletech.ac.in',
    phoneExt: 'Ext. 2421',
    specialization: 'Cryptography, Network Security, Public Key Infrastructure',
    coursesHandled: ['Cryptography & N/W Security (25ECSC304)', 'CNS Lab']
  },
  {
    id: 'f9',
    name: 'Prof. Sushmita P',
    designation: 'Assistant Professor',
    department: 'Computer Science and Engineering',
    cabin: 'CS-214 (2nd Floor Faculty Block)',
    email: 'sushmita.p@kletech.ac.in',
    phoneExt: 'Ext. 2430',
    specialization: 'Cyber Security, Ethical Hacking, Web App Security',
    coursesHandled: ['Cyber Security (25ECSE347)', 'Cyber Security Lab', 'Mini Project Div B']
  }
];

export const KLE_NOTICES: DepartmentNotice[] = [
  {
    id: 'n1',
    title: 'Notification: Approved Odd Semester 2026–27 Timetable w.e.f 7th Sept 2026',
    date: '04 September 2026',
    category: 'Timetable',
    author: 'Dr. Priyanka Gavade (Timetable Officer) & Dr. Rajashri Khanai (HOD)',
    content: 'The class timetable for V Semester B.E. (Divisions A, B, C, D) has been finalized and approved by Dean Academics Dr. Praveen A. Ghorpade. Students and faculty are advised to strictly adhere to designated lecture halls (Step Hall for Div A, MB204 for Div B, MB208 for Div C, and AI Room for Div D).',
    priority: 'high'
  },
  {
    id: 'n2',
    title: 'Laboratory Batch Allotments: 4-Hour Extended Continuous Sessions',
    date: '05 September 2026',
    category: 'Timetable',
    author: 'Department Academic Committee',
    content: 'Students are requested to note that AI-Assisted Software Development Lab (26ECSE346) is scheduled as a continuous 4-hour slot (01:30 PM to 05:30 PM) in Project Lab. Batch 1 comprises Roll Nos 1 to 60, and Batch 2 comprises Roll Nos 61 to 120.',
    priority: 'high'
  },
  {
    id: 'n3',
    title: 'Mini Project (25ECSW301) Phase-1 Synopsis Submission Guidelines',
    date: '08 September 2026',
    category: 'Project',
    author: 'Dr. Rajashri Khanai (Mini Project Coordinator)',
    content: 'All fifth-semester students must submit a 2-page project synopsis endorsed by a faculty mentor by Friday, 18th September. Projects must incorporate modern software engineering techniques, real-world data pipelines, or machine learning solutions.',
    priority: 'normal'
  },
  {
    id: 'n4',
    title: 'Strict Observance of Morning Break (10:00–10:30 AM) and Lunch Recess',
    date: '01 September 2026',
    category: 'General',
    author: 'Dean Academics Office',
    content: 'To safeguard student wellbeing and faculty transition windows, no extra classes, tests, or academic activities are permitted between 10:00–10:30 AM or 12:30–01:30 PM.',
    priority: 'normal'
  }
];

export const KLE_TIMETABLE_ENTRIES: ScheduleEntry[] = [
  // --- DIVISION A (Step Hall) ---
  { id: 'a1', day: 'Mon', time: '08:00 - 09:00', duration: 1, code: '25ECSC309', subject: 'Deep Learning', faculty: 'Dr. Salma Shahapur', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a2', day: 'Mon', time: '09:00 - 10:00', duration: 1, code: '26ECSC313', subject: 'Microcontroller & Embd Systems', faculty: 'Amey Muchandi', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a3', day: 'Mon', time: '10:30 - 11:30', duration: 1, code: '25ECSC304', subject: 'Cryptography & Network Security', faculty: 'U. V. Somanatti', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a4', day: 'Mon', time: '01:30 - 05:30', duration: 4, code: '26ECSE346', subject: 'AI Assisted Soft. Dev. Lab', faculty: 'Dr. Santosh Pattar / Ashwini B', room: 'Project Lab', building: 'CS Wing', type: 'lab', batch: 'Batch 1 (1 to 60)', division: 'A' },
  { id: 'a5', day: 'Mon', time: '01:30 - 03:30', duration: 2, code: '25ECSE347', subject: 'Cyber Security Lab', faculty: 'Sushmita P / Soumya M', room: 'Network Lab', building: 'CS Wing', type: 'lab', batch: 'Batch 2 (61 to 120)', division: 'A' },
  { id: 'a6', day: 'Tue', time: '08:00 - 09:00', duration: 1, code: '25ECSE347', subject: 'Cyber Security', faculty: 'Sushmita P', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a7', day: 'Tue', time: '09:00 - 10:00', duration: 1, code: '26ECSC313', subject: 'Microcontroller & Embd Systems', faculty: 'Amey Muchandi', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a8', day: 'Tue', time: '10:30 - 12:30', duration: 2, code: '26ECSC312', subject: 'WMN Lab', faculty: 'Dr. Ryan Dias / Madhu S / Aarya G', room: 'Network Lab', building: 'CS Wing', type: 'lab', division: 'A' },
  { id: 'a9', day: 'Tue', time: '01:30 - 02:30', duration: 1, code: '23EHSA303', subject: 'ATAR Soft Skills & Aptitude', faculty: 'Priyanka Patil', room: 'Step Hall', building: 'Main Building Block A', type: 'training', division: 'A' },
  { id: 'a10', day: 'Wed', time: '08:00 - 09:00', duration: 1, code: '25ECSE347', subject: 'Cyber Security', faculty: 'Sushmita P', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a11', day: 'Wed', time: '09:00 - 10:00', duration: 1, code: '26ECSC312', subject: 'Wireless & Mobile Networks', faculty: 'Dr. Ryan Dias', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a12', day: 'Wed', time: '10:30 - 11:30', duration: 1, code: '25ECSC309', subject: 'Deep Learning', faculty: 'Dr. Salma Shahapur', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a13', day: 'Wed', time: '11:30 - 12:30', duration: 1, code: '25ECSC304', subject: 'Cryptography & Network Security', faculty: 'U. V. Somanatti', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a14', day: 'Wed', time: '01:30 - 04:30', duration: 3, code: '26ECSP309', subject: 'Deep Learning Lab', faculty: 'Dr. Salma Shahapur / Tabassum J / Swati S', room: 'DL GPU Lab', building: 'Advanced Computing Center', type: 'lab', division: 'A' },
  { id: 'a15', day: 'Thu', time: '08:00 - 10:00', duration: 2, code: '26ECSC313', subject: 'MCES Lab', faculty: 'Amey Muchandi / Akshata P / Supriya N', room: 'Embedded Lab', building: 'Electronics Wing', type: 'lab', division: 'A' },
  { id: 'a16', day: 'Thu', time: '10:30 - 11:30', duration: 1, code: '25ECSC309', subject: 'Deep Learning', faculty: 'Dr. Salma Shahapur', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a17', day: 'Thu', time: '11:30 - 12:30', duration: 1, code: '26ECSE346', subject: 'AI Assisted Software Dev', faculty: 'Dr. Santosh Pattar', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', batch: 'Batch 1 (1 to 60)', division: 'A' },
  { id: 'a18', day: 'Fri', time: '08:00 - 09:00', duration: 1, code: '26ECSC312', subject: 'Wireless & Mobile Networks', faculty: 'Dr. Ryan Dias', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a19', day: 'Fri', time: '09:00 - 10:00', duration: 1, code: '25ECSC309', subject: 'Deep Learning', faculty: 'Dr. Salma Shahapur', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a20', day: 'Fri', time: '10:30 - 11:30', duration: 1, code: '25ECSC304', subject: 'Cryptography & Network Security', faculty: 'U. V. Somanatti', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a21', day: 'Fri', time: '11:30 - 12:30', duration: 1, code: '26ECSC313', subject: 'Microcontroller & Embd Systems', faculty: 'Amey Muchandi', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a22', day: 'Fri', time: '01:30 - 04:30', duration: 3, code: '25ECSW301', subject: 'Mini Project Evaluation', faculty: 'Dr. Rajashri Khanai', room: 'Project Lab', building: 'CS Wing', type: 'project', division: 'A' },
  { id: 'a23', day: 'Sat', time: '08:00 - 09:00', duration: 1, code: '26ECSC312', subject: 'Wireless & Mobile Networks', faculty: 'Dr. Ryan Dias', room: 'Step Hall', building: 'Main Building Block A', type: 'theory', division: 'A' },
  { id: 'a24', day: 'Sat', time: '09:00 - 11:00', duration: 2, code: '25ECSC304', subject: 'CNS Lab', faculty: 'U. V. Somanatti / Sakshi S', room: 'Network Lab', building: 'CS Wing', type: 'lab', division: 'A' },

  // --- DIVISION B (MB204) ---
  { id: 'b1', day: 'Mon', time: '08:00 - 09:00', duration: 1, code: '25ECSC309', subject: 'Deep Learning', faculty: 'Tabassum J', room: 'MB204', building: 'Main Building Block A', type: 'theory', division: 'B' },
  { id: 'b2', day: 'Mon', time: '09:00 - 10:00', duration: 1, code: '25ECSC304', subject: 'Cryptography & Network Security', faculty: 'Neha Nimbalkar', room: 'MB204', building: 'Main Building Block A', type: 'theory', division: 'B' },
  { id: 'b3', day: 'Mon', time: '10:30 - 11:30', duration: 1, code: '26ECSC312', subject: 'Wireless & Mobile Networks', faculty: 'Madhurani S', room: 'MB204', building: 'Main Building Block A', type: 'theory', division: 'B' },
  { id: 'b4', day: 'Mon', time: '11:30 - 12:30', duration: 1, code: '26ECSC313', subject: 'Microcontroller & Embd Systems', faculty: 'Amey Muchandi', room: 'MB204', building: 'Main Building Block A', type: 'theory', division: 'B' },
  { id: 'b5', day: 'Tue', time: '10:30 - 12:30', duration: 2, code: '26ECSP309', subject: 'Deep Learning Lab', faculty: 'Tabassum J / Dr. Salma S / Swati S', room: 'DL GPU Lab', building: 'Advanced Computing Center', type: 'lab', division: 'B' },
  { id: 'b6', day: 'Tue', time: '01:30 - 03:30', duration: 2, code: '26ECSC313', subject: 'MCES Lab', faculty: 'Amey Muchandi / Akshata P / Ashwini B', room: 'Embedded Lab', building: 'Electronics Wing', type: 'lab', division: 'B' },
  { id: 'b7', day: 'Wed', time: '08:00 - 09:00', duration: 1, code: '25ECSE347', subject: 'Cyber Security', faculty: 'Sushmita P', room: 'MB204', building: 'Main Building Block A', type: 'theory', division: 'B' },
  { id: 'b8', day: 'Thu', time: '01:30 - 05:30', duration: 4, code: '26ECSE346', subject: 'AI Assisted Soft. Dev. Lab', faculty: 'Dr. Santosh Pattar / Ashwini B', room: 'Project Lab', building: 'CS Wing', type: 'lab', batch: 'Batch 2 (61 to 120)', division: 'B' },
  { id: 'b9', day: 'Fri', time: '01:30 - 04:30', duration: 3, code: '25ECSW301', subject: 'Mini Project Evaluation', faculty: 'Sushmita P', room: 'Project Lab', building: 'CS Wing', type: 'project', division: 'B' },

  // --- DIVISION C (MB208) ---
  { id: 'c1', day: 'Mon', time: '08:00 - 09:00', duration: 1, code: '25ECSC304', subject: 'Cryptography & Network Security', faculty: 'Neha Nimbalkar', room: 'MB208', building: 'Main Building Block A', type: 'theory', division: 'C' },
  { id: 'c2', day: 'Mon', time: '09:00 - 10:00', duration: 1, code: '26ECSC312', subject: 'Wireless & Mobile Networks', faculty: 'Supriya Belkar', room: 'MB208', building: 'Main Building Block A', type: 'theory', division: 'C' },
  { id: 'c3', day: 'Mon', time: '10:30 - 11:30', duration: 1, code: '25ECSC309', subject: 'Deep Learning', faculty: 'Tabassum J', room: 'MB208', building: 'Main Building Block A', type: 'theory', division: 'C' },
  { id: 'c4', day: 'Mon', time: '11:30 - 12:30', duration: 1, code: '26ECSC313', subject: 'Microcontroller & Embd Systems', faculty: 'Dr. Niranjan Muchandi', room: 'MB208', building: 'Main Building Block A', type: 'theory', division: 'C' },
  { id: 'c5', day: 'Mon', time: '01:30 - 03:30', duration: 2, code: '25ECSE347', subject: 'Cyber Security Lab', faculty: 'Sushmita P / Soumya M', room: 'Network Lab', building: 'CS Wing', type: 'lab', division: 'C' },
  { id: 'c6', day: 'Tue', time: '10:30 - 12:30', duration: 2, code: '26ECSC313', subject: 'MCES Lab', faculty: 'Dr. Niranjan M / Akshata P / Supriya N', room: 'Embedded Lab', building: 'Electronics Wing', type: 'lab', division: 'C' },
  { id: 'c7', day: 'Tue', time: '01:30 - 04:30', duration: 3, code: '26ECSP309', subject: 'Deep Learning Lab', faculty: 'Tabassum J / Dr. Prema T / Swati S', room: 'DL GPU Lab', building: 'Advanced Computing Center', type: 'lab', division: 'C' },
  { id: 'c8', day: 'Thu', time: '01:30 - 05:30', duration: 4, code: '26ECSE346', subject: 'AI Assisted Soft. Dev. Lab', faculty: 'Dr. Santosh Pattar / Ashwini B', room: 'Project Lab', building: 'CS Wing', type: 'lab', batch: 'Batch 2 (61 to 120)', division: 'C' },
  { id: 'c9', day: 'Fri', time: '01:30 - 04:30', duration: 3, code: '25ECSW301', subject: 'Mini Project Evaluation', faculty: 'Dr. Niranjan Muchandi', room: 'Project Lab', building: 'CS Wing', type: 'project', division: 'C' },

  // --- DIVISION D (AI Room) ---
  { id: 'd1', day: 'Mon', time: '08:00 - 09:00', duration: 1, code: '26ECAC301', subject: 'Cloud Computing', faculty: 'Madhurani S', room: 'AI Room', building: 'CS Wing', type: 'theory', division: 'D' },
  { id: 'd2', day: 'Mon', time: '09:00 - 10:00', duration: 1, code: '26ECAC304', subject: 'Parallel and GPU Computing', faculty: 'Dr. Santosh Pattar', room: 'AI Room', building: 'CS Wing', type: 'theory', division: 'D' },
  { id: 'd3', day: 'Mon', time: '10:30 - 11:30', duration: 1, code: '26ECAC302', subject: 'Deep Learning', faculty: 'Dr. Prema T. A.', room: 'AI Room', building: 'CS Wing', type: 'theory', division: 'D' },
  { id: 'd4', day: 'Tue', time: '08:00 - 10:00', duration: 2, code: '26ECAC301', subject: 'Cloud Computing Lab', faculty: 'Madhurani S / Shrigouri M', room: 'Network Lab', building: 'CS Wing', type: 'lab', division: 'D' },
  { id: 'd5', day: 'Wed', time: '10:30 - 12:30', duration: 2, code: '26ECAC304', subject: 'PGPUC Lab', faculty: 'Dr. Santosh Pattar / Ashwini B', room: 'DL GPU Lab', building: 'Advanced Computing Center', type: 'lab', division: 'D' },
  { id: 'd6', day: 'Thu', time: '01:30 - 04:30', duration: 3, code: '26ECAC302', subject: 'Deep Learning Lab', faculty: 'Dr. Prema T. A. / Dr. Salma S / Swati S', room: 'DL GPU Lab', building: 'Advanced Computing Center', type: 'lab', division: 'D' },
  { id: 'd7', day: 'Fri', time: '01:30 - 04:30', duration: 3, code: '22ECAW301', subject: 'Mini Project Evaluation', faculty: 'Amey Muchandi', room: 'Project Lab', building: 'CS Wing', type: 'project', division: 'D' },
];

export const DEMO_USERS_DATABASE = [
  {
    email: 'admin@auro.edu',
    password: 'admin123',
    role: 'admin' as const,
    roleLabel: 'Dean of Academic Affairs',
    full_name: 'Dr. Praveen A. Ghorpade',
    description: 'Executive campus administrator governing all 4 blocks and academic policies.',
    department_name: 'Academic Affairs & Senate',
    designation: 'Professor & Dean Academics',
    office_room: 'Admin Block, Room 201',
    badgeColor: 'bg-rose-50 text-rose-800 border-rose-200',
    location: 'Admin Block 201',
    cohort: 'Campus-wide Administration',
  },
  {
    email: 'hod.cse@auro.edu',
    password: 'admin123',
    role: 'admin' as const,
    roleLabel: 'Head of Department (CSE)',
    full_name: 'Dr. Rajashri Khanai',
    description: 'HOD of Computer Science & Engineering, overseeing all department faculty & curriculum.',
    department_name: 'Computer Science & Engineering',
    designation: 'Professor & Head of Department',
    office_room: 'CS-101 (HOD Chamber)',
    badgeColor: 'bg-indigo-50 text-indigo-800 border-indigo-200',
    location: 'CS Wing 101',
    cohort: 'CSE Department Head',
  },
  {
    email: 'coordinator@auro.edu',
    password: 'coord123',
    role: 'coordinator' as const,
    roleLabel: 'Timetable Scheduling Officer',
    full_name: 'Dr. Priyanka Gavade',
    description: 'Timetable Officer responsible for DSA slot scheduling, conflict auditing & room allocations.',
    department_name: 'Computer Science & Engineering',
    designation: 'Assistant Professor & Timetable Officer',
    office_room: 'CS-104 (Faculty Block A)',
    badgeColor: 'bg-amber-50 text-amber-800 border-amber-200',
    location: 'Faculty Block A 104',
    cohort: 'Timetable & Curriculum Cell',
  },
  {
    email: 'salma@auro.edu',
    password: 'faculty123',
    role: 'faculty' as const,
    roleLabel: 'Associate Professor',
    full_name: 'Dr. Salma Shahapur',
    description: 'Lead instructor for Deep Learning (25ECSC309) & Deep Learning Lab in GPU Center.',
    department_name: 'Computer Science & Engineering',
    designation: 'Associate Professor (Deep Learning)',
    office_room: 'CS-205 (Faculty Block A)',
    badgeColor: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    location: 'CS-205',
    cohort: 'CSE Faculty Lead',
  },
  {
    email: 'amey@auro.edu',
    password: 'faculty123',
    role: 'faculty' as const,
    roleLabel: 'Assistant Professor',
    full_name: 'Prof. Amey Muchandi',
    description: 'Instructor for Microcontrollers & Embedded Systems (26ECSC313) and IoT lab in-charge.',
    department_name: 'Computer Science & Engineering',
    designation: 'Assistant Professor (Embedded Systems)',
    office_room: 'CS-210 (Faculty Block A)',
    badgeColor: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    location: 'CS-210',
    cohort: 'CSE Faculty Lead',
  },
  {
    email: 'student.a@auro.edu',
    password: 'student123',
    role: 'student' as const,
    roleLabel: 'V Sem Student — Div A',
    full_name: 'Rohan Deshmukh',
    description: '5th Semester B.E. student in Section A. Lectures held in Step Hall amphitheater.',
    department_name: 'Computer Science & Engineering',
    designation: 'B.E. Student (5th Sem)',
    division: 'A' as const,
    office_room: 'Step Hall (Primary Hall)',
    roll_number: '2KA23CS084',
    badgeColor: 'bg-sky-50 text-sky-800 border-sky-200',
    location: 'Step Hall',
    cohort: 'Division A (Roll 84 - Batch 2)',
  },
  {
    email: 'student.d@auro.edu',
    password: 'student123',
    role: 'student' as const,
    roleLabel: 'V Sem Student — Div D (AI)',
    full_name: 'Pooja Hegde',
    description: '5th Semester B.E. student in Section D (Specialized AI/GPU Track, AI Room).',
    department_name: 'Computer Science & Engineering',
    designation: 'B.E. Student (AI Specialization)',
    division: 'D' as const,
    office_room: 'AI Room (Primary Hall)',
    roll_number: '2KA23CS142',
    badgeColor: 'bg-purple-50 text-purple-800 border-purple-200',
    location: 'AI Room',
    cohort: 'Division D (AI/GPU Track)',
  },
  {
    email: 'hod.ece@auro.edu',
    password: 'ecehod123',
    role: 'admin' as const,
    roleLabel: 'Head of Department (ECE)',
    full_name: 'Dr. Suresh R. Hebbar',
    description: 'HOD of Electronics & Communication Engineering, Block B.',
    department_name: 'Electronics & Communication Engineering',
    designation: 'Professor & Head of Department',
    office_room: 'EC-101 (HOD Chamber)',
    badgeColor: 'bg-indigo-50 text-indigo-800 border-indigo-200',
    location: 'EC Wing 101',
    cohort: 'ECE Department Head',
  },
  {
    email: 'coordinator.ece@auro.edu',
    password: 'ececoord123',
    role: 'coordinator' as const,
    roleLabel: 'Timetable Scheduling Officer (ECE)',
    full_name: 'Prof. Nandini Kulkarni',
    description: 'Timetable Officer for Electronics & Communication Engineering.',
    department_name: 'Electronics & Communication Engineering',
    designation: 'Assistant Professor & Timetable Officer',
    office_room: 'EC-104 (Faculty Block B)',
    badgeColor: 'bg-amber-50 text-amber-800 border-amber-200',
    location: 'Faculty Block B 104',
    cohort: 'Timetable & Curriculum Cell',
  },
  {
    email: 'hod.mech@auro.edu',
    password: 'mechhod123',
    role: 'admin' as const,
    roleLabel: 'Head of Department (Mechanical)',
    full_name: 'Dr. Anand V. Desai',
    description: 'HOD of Mechanical Engineering, Block C.',
    department_name: 'Mechanical Engineering',
    designation: 'Professor & Head of Department',
    office_room: 'MC-101 (HOD Chamber)',
    badgeColor: 'bg-indigo-50 text-indigo-800 border-indigo-200',
    location: 'Mechanical Wing 101',
    cohort: 'Mechanical Department Head',
  },
  {
    email: 'coordinator.mech@auro.edu',
    password: 'mechcoord123',
    role: 'coordinator' as const,
    roleLabel: 'Timetable Scheduling Officer (Mechanical)',
    full_name: 'Dr. Kiran M. Patil',
    description: 'Timetable Officer for Mechanical Engineering.',
    department_name: 'Mechanical Engineering',
    designation: 'Assistant Professor & Timetable Officer',
    office_room: 'MC-104 (Faculty Block C)',
    badgeColor: 'bg-amber-50 text-amber-800 border-amber-200',
    location: 'Faculty Block C 104',
    cohort: 'Timetable & Curriculum Cell',
  },
  {
    email: 'hod.civil@auro.edu',
    password: 'civilhod123',
    role: 'admin' as const,
    roleLabel: 'Head of Department (Civil)',
    full_name: 'Dr. Meena S. Joshi',
    description: 'HOD of Civil Engineering, Block D.',
    department_name: 'Civil Engineering',
    designation: 'Professor & Head of Department',
    office_room: 'CV-101 (HOD Chamber)',
    badgeColor: 'bg-indigo-50 text-indigo-800 border-indigo-200',
    location: 'Civil Wing 101',
    cohort: 'Civil Department Head',
  },
  {
    email: 'coordinator.civil@auro.edu',
    password: 'civilcoord123',
    role: 'coordinator' as const,
    roleLabel: 'Timetable Scheduling Officer (Civil)',
    full_name: 'Prof. Rohit S. Halemani',
    description: 'Timetable Officer for Civil Engineering.',
    department_name: 'Civil Engineering',
    designation: 'Assistant Professor & Timetable Officer',
    office_room: 'CV-104 (Faculty Block D)',
    badgeColor: 'bg-amber-50 text-amber-800 border-amber-200',
    location: 'Faculty Block D 104',
    cohort: 'Timetable & Curriculum Cell',
  },
];
