export type Day = 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat';

export type PeriodId = 'P1' | 'P2' | 'P3' | 'P4' | 'P5' | 'P6' | 'P7' | 'P8';

export type Division = 'A' | 'B' | 'C' | 'D';

export type BatchId = 'FULL' | 'B1' | 'B2';

export type SessionType = 'theory' | 'lab' | 'project';

export interface TimeSlot {
  id: PeriodId;
  index: number;
  start: string;
  end: string;
  label: string;
}

export interface Room {
  id: string;
  name: string;
  type: 'lecture-hall' | 'laboratory';
  capacity: number;
  building: string;
}

export interface Faculty {
  id: string;
  name: string;
  designation: string;
  unavailableSlots: string[];
  preferredSlots: string[];
}

export interface StudentGroup {
  id: string;
  division: Division;
  batch: BatchId;
  size: number;
}

export interface Activity {
  id: string;
  courseCode: string;
  courseTitle: string;
  facultyIds: string[];
  groupId: string;
  duration: number;
  sessionType: SessionType;
  allowedRoomIds: string[];
}

export interface DomainValue {
  day: Day;
  start: PeriodId;
  roomId: string;
  periods: PeriodId[];
}

export interface Assignment {
  activityId: string;
  day: Day;
  start: PeriodId;
  roomId: string;
  periods: PeriodId[];
}

export interface SchedulingProblem {
  days: Day[];
  slots: TimeSlot[];
  rooms: Room[];
  faculty: Faculty[];
  groups: StudentGroup[];
  activities: Activity[];
  facultyAvailability: Map<string, Map<string, boolean>>;
  facultyPreferences: Map<string, Set<string>>;
  unavailability: { resourceId: string; resourceType: 'faculty' | 'room'; day: Day; period: PeriodId }[];
}

export interface SearchMetrics {
  vertices: number;
  edges: number;
  graphDensity: number;
  edgesByReason: { faculty: number; group: number; room: number };
  maxDegree: number;
  averageDegree: number;
  dsaturOrderFirst: string[];
  iterations: number;
  backtracks: number;
  prunes: number;
  maxDepth: number;
  elapsedMs: number;
  solved: boolean;
}

export interface HardConstraintCheck {
  id: string;
  label: string;
  passed: boolean;
  violations: string[];
}

export interface SoftScoreBreakdown {
  facultyPreference: number;
  gapPenalty: number;
  loadBalance: number;
  roomUtilization: number;
  total: number;
  maxTotal: number;
}

export interface GenerationResult {
  assignments: Assignment[];
  metrics: SearchMetrics;
  hardValidation: HardConstraintCheck[];
  softScore: SoftScoreBreakdown;
  generatedAt: string;
}

export const PERIOD_BLOCK_STARTS: Record<number, PeriodId[]> = {
  1: ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7'],
  2: ['P1', 'P3', 'P5'],
  3: ['P5'],
  4: ['P5'],
};
