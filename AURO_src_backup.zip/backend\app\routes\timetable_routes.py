"""
/timetable routes — metadata, generation (staff only) and the cached
current timetable for role-based dashboards.

Generation responses are enriched: every assignment row is joined with
its activity + faculty + group metadata (camelCase keys so the React
client can consume it directly).
"""

from typing import Dict

from fastapi import APIRouter, Depends, HTTPException

from ..auth import require_any, require_staff
from ..data.curriculum import (
    DAYS,
    FACULTY,
    ROOMS,
    STUDENT_GROUPS,
    build_scheduling_problem,
)
from ..engine.generator.timetable_generator import generate_timetable
from ..services.store import timetable_store

router = APIRouter(prefix="/api/v1/timetable", tags=["timetable"])


def _enrich(payload: dict, group_meta: Dict[str, dict]) -> dict:
    faculty_names = {f.id: f.name for f in FACULTY}
    activity_by_id = {a.id: a for a in payload["activities"]}

    rows = []
    for a in payload["assignments"]:
        act = activity_by_id[a["activityId"]]
        meta = group_meta.get(act.group_id, {"division": "?", "batch": "FULL"})
        rows.append({
            **a,
            "courseCode": act.course_code,
            "courseTitle": act.course_title,
            "sessionType": act.session_type,
            "duration": act.duration,
            "facultyIds": act.faculty_ids,
            "facultyNames": [faculty_names.get(f, f) for f in act.faculty_ids],
            "groupId": act.group_id,
            "division": meta["division"],
            "batch": meta["batch"],
        })

    return {**payload, "assignments": rows}


@router.get("/meta")
def meta(user: dict = Depends(require_any)):
    problem = build_scheduling_problem()
    return {
        "program": "B.E. Computer Science & Engineering",
        "semester": "V",
        "academicYear": "2026–27",
        "facultyCount": len(FACULTY),
        "roomCount": len(ROOMS),
        "groupCount": len(STUDENT_GROUPS),
        "activityCount": len(problem.activities),
        "divisions": ["A", "B", "C", "D"],
        "days": DAYS,
        "engines": [
            {"id": "dsa", "name": "DSA Engine", "status": "IMPLEMENTED", "weight": "35%"},
            {"id": "dbms", "name": "DBMS Engine", "status": "PLANNED", "weight": "25%"},
            {"id": "os", "name": "OS Engine", "status": "PLANNED", "weight": "20%"},
            {"id": "web", "name": "Web & Networks", "status": "ACTIVE", "weight": "20%"},
        ],
    }


@router.post("/generate")
def generate(user: dict = Depends(require_staff)):
    problem = build_scheduling_problem()
    result = generate_timetable(problem)

    group_meta = {g.id: {"division": g.division, "batch": g.batch} for g in problem.groups}
    payload = _enrich({**result, "activities": problem.activities}, group_meta)
    timetable_store.set(payload)
    return payload


@router.get("/current")
def current(user: dict = Depends(require_any)):
    payload = timetable_store.get()
    if payload is None:
        raise HTTPException(
            status_code=404,
            detail="No timetable generated yet. Ask a coordinator or admin to run the engine.",
        )
    return payload
