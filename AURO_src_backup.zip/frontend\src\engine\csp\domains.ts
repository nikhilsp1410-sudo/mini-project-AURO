import { PERIOD_BLOCK_STARTS, Day, DomainValue, PeriodId, SchedulingProblem } from '../core/types';

export const buildDomains = (problem: SchedulingProblem): Map<string, DomainValue[]> => {
  const domains = new Map<string, DomainValue[]>();

  for (const activity of problem.activities) {
    const values: DomainValue[] = [];
    const starts = PERIOD_BLOCK_STARTS[activity.duration] ?? PERIOD_BLOCK_STARTS[1];

    for (const day of problem.days) {
      for (const start of starts) {
        const periods = coverPeriods(problem, start, activity.duration);
        if (periods.length < activity.duration) continue;

        for (const roomId of activity.allowedRoomIds) {
          const room = problem.rooms.find((r) => r.id === roomId)!;
          if (!roomActive(room, day, periods, problem)) continue;

          const facultyFree = activity.facultyIds.every((fid) =>
            periods.every((p) => facultyAvailable(problem, fid, day, p.id))
          );
          if (!facultyFree) continue;

          values.push({ day, start, roomId, periods: periods.map((p) => p.id) });
        }
      }
    }
    domains.set(activity.id, values);
  }
  return domains;
};

const coverPeriods = (problem: SchedulingProblem, start: PeriodId, duration: number) => {
  const startIdx = problem.slots.find((s) => s.id === start)!.index;
  return problem.slots.filter((s) => s.index >= startIdx && s.index < startIdx + duration);
};

const facultyAvailable = (problem: SchedulingProblem, facultyId: string, day: Day, period: PeriodId): boolean => {
  const blocked = problem.unavailability.some(
    (u) => u.resourceType === 'faculty' && u.resourceId === facultyId && u.day === day && u.period === period
  );
  if (blocked) return false;
  return problem.facultyAvailability.get(facultyId)?.get(`${day}:${period}`) ?? true;
};

const roomActive = (
  room: { id: string },
  day: Day,
  periods: Array<{ id: string }>,
  problem: SchedulingProblem
): boolean => {
  return !problem.unavailability.some(
    (u) => u.resourceType === 'room' && u.resourceId === room.id && u.day === day && periods.some((p) => p.id === u.period)
  );
};
