"""
Authentication dependencies: bearer-token extraction and role checks.
"""

from typing import List, Optional

from fastapi import Depends, Header, HTTPException

from .data.users import public_user
from .services.store import session_store


def _token_from_header(authorization: Optional[str]) -> Optional[str]:
    if authorization and authorization.startswith("Bearer "):
        return authorization[len("Bearer "):]
    return None


# Public alias for routes that need the raw token (e.g. logout)
token_from_header = _token_from_header


def get_current_user(authorization: Optional[str] = Header(default=None)) -> dict:
    user = session_store.get(_token_from_header(authorization))
    if user is None:
        raise HTTPException(status_code=401, detail="Not authenticated. Please log in.")
    return user


def require_roles(roles: List[str]):
    def checker(user: dict = Depends(get_current_user)) -> dict:
        if user["role"] not in roles:
            raise HTTPException(
                status_code=403,
                detail=f"Access denied. This action requires role: {' or '.join(roles)}.",
            )
        return user

    return checker


# Convenience guards
require_staff = require_roles(["admin", "coordinator"])  # can run the engine
require_any = get_current_user  # any authenticated role
