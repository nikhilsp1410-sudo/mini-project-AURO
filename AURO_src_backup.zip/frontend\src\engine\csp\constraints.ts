import { ResourceRegistry, slotKey } from '../core/registry';
import {
  Assignment,
  DomainValue,
  HardConstraintCheck,
  SchedulingProblem,
  SoftScoreBreakdown,
} from '../core/types';

export interface SolverState {
  byRoom: Map<string, Set<string>>;
  byFaculty: Map<string, Set<string>>;
  byGroup: Map<string, Set<string>>;
}

export const createState = (): SolverState => ({
  byRoom: new Map(),
  byFaculty: new Map(),
  byGroup: new Map(),
});

const addBusy = (map: Map<string, Set<string>>, key: string, slots: string[]) => {
  if (!map.has(key)) map.set(key, new Set());
  const set = map.get(key)!;
  slots.forEach((s) => set.add(s));
};

const removeBusy = (map: Map<string, Set<string>>, key: string, slots: string[]) => {
  const set = map.get(key);
  if (!set) return;
  slots.forEach((s) => set.delete(s));
};

export const assign = (
  state: SolverState,
  value: DomainValue,
  facultyIds: string[],
  groupId: string
): void => {
  const slots = value.periods.map((p) => slotKey(value.day, p));
  addBusy(state.byRoom, value.roomId, slots);
  facultyIds.forEach((f) => addBusy(state.byFaculty, f, slots));
  addBusy(state.byGroup, groupId, slots);
};

export const unassign = (
  state: SolverState,
  value: DomainValue,
  facultyIds: string[],
  groupId: string
): void => {
  const slots = value.periods.map((p) => slotKey(value.day, p));
  removeBusy(state.byRoom, value.roomId, slots);
  facultyIds.forEach((f) => removeBusy(state.byFaculty, f, slots));
  removeBusy(state.byGroup, groupId, slots);
};

export const valueConflicts = (
  state: SolverState,
  value: DomainValue,
  facultyIds: string[],
  groupId: string,
  overlappingGroups: string[]
): boolean => {
  const slots = value.periods.map((p) => slotKey(value.day, p));
  const overlaps = (set: Set<string> | undefined) => slots.some((s) => set?.has(s));
  if (overlaps(state.byRoom.get(value.roomId))) return true;
  for (const f of facultyIds) {
    if (overlaps(state.byFaculty.get(f))) return true;
  }
  if (overlaps(state.byGroup.get(groupId))) return true;
  for (const g of overlappingGroups) {
    if (g !== groupId && overlaps(state.byGroup.get(g))) return true;
  }
  return false;
};

export const validateHardConstraints = (
  assignments: Assignment[],
  problem: SchedulingProblem,
  registry: ResourceRegistry
): HardConstraintCheck[] => {
  const checks: HardConstraintCheck[] = [];

  const roomViolations: string[] = [];
  const facultyViolations: string[] = [];
  const groupViolations: string[] = [];
  const capacityViolations: string[] = [];
  const roomTypeViolations: string[] = [];
  const availabilityViolations: string[] = [];
  const unavailabilityViolations: string[] = [];

  const label = (a: Assignment) => {
    const act = registry.getActivity(a.activityId);
    return `${act?.courseCode ?? a.activityId} (${a.day} ${a.start})`;
  };

  for (let i = 0; i < assignments.length; i++) {
    for (let j = i + 1; j < assignments.length; j++) {
      const a = assignments[i];
      const b = assignments[j];
      const aPeriods = new Set(a.periods);
      const overlap = a.day === b.day && b.periods.some((p) => aPeriods.has(p));
      if (!overlap) continue;

      if (a.roomId === b.roomId) {
        roomViolations.push(`${label(a)} vs ${label(b)} share room ${a.roomId}`);
      }

      const actA = registry.getActivity(a.activityId)!;
      const actB = registry.getActivity(b.activityId)!;
      const sharedFaculty = actA.facultyIds.filter((f) => actB.facultyIds.includes(f));
      if (sharedFaculty.length > 0) {
        facultyViolations.push(
          `${label(a)} vs ${label(b)} share faculty ${sharedFaculty.map((f) => registry.faculty.get(f)?.name ?? f).join(', ')}`
        );
      }

      const aGroup = registry.groups.get(actA.groupId)!;
      const bGroup = registry.groups.get(actB.groupId)!;
      const groupsOverlap =
        actA.groupId === actB.groupId ||
        (aGroup.division === bGroup.division &&
          (aGroup.batch === 'FULL' || bGroup.batch === 'FULL' || aGroup.batch === bGroup.batch));
      if (groupsOverlap) {
        groupViolations.push(`${label(a)} vs ${label(b)} share student group ${aGroup.division}`);
      }
    }
  }

  for (const a of assignments) {
    const act = registry.getActivity(a.activityId)!;
    const room = registry.getRoom(a.roomId)!;
    const group = registry.groups.get(act.groupId)!;

    if (room.capacity < group.size) {
      capacityViolations.push(`${label(a)}: ${group.size} students exceed ${room.id} capacity ${room.capacity}`);
    }

    const needsLab = act.sessionType !== 'theory';
    if (needsLab && room.type !== 'laboratory') {
      roomTypeViolations.push(`${label(a)}: ${act.sessionType} session assigned to non-lab room ${room.id}`);
    }
    if (!needsLab && room.type !== 'lecture-hall') {
      roomTypeViolations.push(`${label(a)}: theory session assigned to non-lecture-hall ${room.id}`);
    }

    for (const fid of act.facultyIds) {
      for (const p of a.periods) {
        if (!registry.isFacultyAvailable(fid, slotKey(a.day, p))) {
          availabilityViolations.push(
            `${label(a)}: ${registry.faculty.get(fid)?.name ?? fid} unavailable ${a.day} ${p}`
          );
        }
        const blocked = problem.unavailability.some(
          (u) => u.resourceType === 'room' && u.resourceId === a.roomId && u.day === a.day && u.period === p
        );
        if (blocked) {
          unavailabilityViolations.push(`${label(a)}: room ${a.roomId} unavailable ${a.day} ${p}`);
        }
      }
    }
  }

  checks.push({ id: 'HC-1', label: 'Room exclusivity — no room double-booked', passed: roomViolations.length === 0, violations: roomViolations });
  checks.push({ id: 'HC-2', label: 'Faculty exclusivity — no faculty teaching two classes simultaneously', passed: facultyViolations.length === 0, violations: facultyViolations });
  checks.push({ id: 'HC-3', label: 'Batch exclusivity — no batch attending two classes simultaneously', passed: groupViolations.length === 0, violations: groupViolations });
  checks.push({ id: 'HC-4', label: 'Room capacity — room holds the batch size', passed: capacityViolations.length === 0, violations: capacityViolations });
  checks.push({ id: 'HC-5', label: 'Room type — labs in laboratories, theory in lecture halls', passed: roomTypeViolations.length === 0, violations: roomTypeViolations });
  checks.push({ id: 'HC-6', label: 'Faculty availability — faculty free in assigned slot', passed: availabilityViolations.length === 0, violations: availabilityViolations });
  checks.push({ id: 'HC-7', label: 'Resource availability — no unavailable room assigned', passed: unavailabilityViolations.length === 0, violations: unavailabilityViolations });

  return checks;
};

export const computeSoftScore = (
  assignments: Assignment[],
  problem: SchedulingProblem,
  registry: ResourceRegistry,
  _weights = { facultyPreference: 10, gapPenalty: 4, loadBalance: 3, utilization: 6 }
): SoftScoreBreakdown => {
  let preferenceHits = 0;
  let preferenceTotal = 0;

  for (const a of assignments) {
    const act = registry.getActivity(a.activityId)!;
    for (const fid of act.facultyIds) {
      preferenceTotal += 1;
      const prefs = problem.facultyPreferences.get(fid);
      if (prefs && a.periods.some((p) => prefs.has(`${a.day}:${p}`))) {
        preferenceHits += 1;
      }
    }
  }

  let totalGaps = 0;
  const dailyLoads = new Map<string, number[]>();

  for (const a of assignments) {
    const act = registry.getActivity(a.activityId)!;
    for (const fid of act.facultyIds) {
      if (!dailyLoads.has(fid)) dailyLoads.set(fid, [0, 0, 0, 0, 0, 0]);
      const dayIdx = problem.days.indexOf(a.day);
      dailyLoads.get(fid)![dayIdx] += act.duration;
    }
  }

  for (const fid of dailyLoads.keys()) {
    for (let d = 0; d < problem.days.length; d++) {
      const day = problem.days[d];
      const slotsToday = assignments
        .filter((a) => {
          const act = registry.getActivity(a.activityId)!;
          return a.day === day && act.facultyIds.includes(fid);
        })
        .map((a) => ({
          start: problem.slots.find((s) => s.id === a.start)!.index,
          end: problem.slots.find((s) => s.id === a.start)!.index + registry.getActivity(a.activityId)!.duration - 1,
        }))
        .sort((x, y) => x.start - y.start);

      for (let i = 1; i < slotsToday.length; i++) {
        if (slotsToday[i].start > slotsToday[i - 1].end + 1) totalGaps += slotsToday[i].start - slotsToday[i - 1].end - 1;
      }
    }
  }

  let loadVarianceSum = 0;
  for (const loads of dailyLoads.values()) {
    const mean = loads.reduce((s, v) => s + v, 0) / loads.length;
    loadVarianceSum += loads.reduce((s, v) => s + (v - mean) ** 2, 0) / loads.length;
  }

  let utilizationSum = 0;
  for (const a of assignments) {
    const act = registry.getActivity(a.activityId)!;
    const room = registry.getRoom(a.roomId)!;
    const group = registry.groups.get(act.groupId)!;
    utilizationSum += Math.min(1, group.size / room.capacity) * act.duration;
  }
  const totalActivityHours = assignments.reduce((s, a) => s + registry.getActivity(a.activityId)!.duration, 0);
  const utilization = totalActivityHours > 0 ? (utilizationSum / totalActivityHours) * 100 : 0;

  const facultyPreference = preferenceTotal > 0 ? (preferenceHits / preferenceTotal) * 100 : 0;
  const gapPenalty = totalGaps;
  const loadBalance = loadVarianceSum / Math.max(1, dailyLoads.size);

  return {
    facultyPreference: Number(facultyPreference.toFixed(1)),
    gapPenalty,
    loadBalance: Number(loadBalance.toFixed(2)),
    roomUtilization: Number(utilization.toFixed(1)),
    total: 0,
    maxTotal: 100,
  };
};
