"""
CSP constraint management.

SolverState tracks busy time-slots per resource using hash maps of sets:
  byRoom / byFaculty / byGroup: resource_id -> {'Mon:P5', 'Mon:P6', ...}

assign / unassign keep the state consistent during backtracking; the
hard-constraint validator (HC-1 .. HC-7) audits a finished assignment
list; compute_soft_score evaluates schedule quality.
"""

from typing import Dict, Iterable, List, Set

from ..core.registry import ResourceRegistry, slot_key
from ..core.types import Assignment, DomainValue, SchedulingProblem


class SolverState:
    def __init__(self) -> None:
        self.by_room: Dict[str, Set[str]] = {}
        self.by_faculty: Dict[str, Set[str]] = {}
        self.by_group: Dict[str, Set[str]] = {}


def _add_busy(map_: Dict[str, Set[str]], key: str, slots: Iterable[str]) -> None:
    map_.setdefault(key, set()).update(slots)


def _remove_busy(map_: Dict[str, Set[str]], key: str, slots: Iterable[str]) -> None:
    busy = map_.get(key)
    if busy is not None:
        busy.difference_update(slots)


def assign(state: SolverState, value: DomainValue, faculty_ids: List[str], group_id: str) -> None:
    slots = [slot_key(value.day, p) for p in value.periods]
    _add_busy(state.by_room, value.room_id, slots)
    for fid in faculty_ids:
        _add_busy(state.by_faculty, fid, slots)
    _add_busy(state.by_group, group_id, slots)


def unassign(state: SolverState, value: DomainValue, faculty_ids: List[str], group_id: str) -> None:
    slots = [slot_key(value.day, p) for p in value.periods]
    _remove_busy(state.by_room, value.room_id, slots)
    for fid in faculty_ids:
        _remove_busy(state.by_faculty, fid, slots)
    _remove_busy(state.by_group, group_id, slots)


def value_conflicts(
    state: SolverState,
    value: DomainValue,
    faculty_ids: List[str],
    group_id: str,
    overlapping_groups: List[str],
) -> bool:
    slots = {slot_key(value.day, p) for p in value.periods}

    def overlaps(busy: Set[str]) -> bool:
        return bool(slots & busy)

    if value.room_id in state.by_room and overlaps(state.by_room[value.room_id]):
        return True
    for fid in faculty_ids:
        if fid in state.by_faculty and overlaps(state.by_faculty[fid]):
            return True
    if group_id in state.by_group and overlaps(state.by_group[group_id]):
        return True
    for group in overlapping_groups:
        if group != group_id and group in state.by_group and overlaps(state.by_group[group]):
            return True
    return False


def groups_overlap(registry: ResourceRegistry, group_a: str, group_b: str) -> bool:
    """True when the two student groups share students (symmetric)."""
    if group_a == group_b:
        return True
    a = registry.groups.get(group_a)
    b = registry.groups.get(group_b)
    if a is None or b is None:
        return False
    return a.division == b.division and (
        a.batch == "FULL" or b.batch == "FULL" or a.batch == b.batch
    )


def validate_hard_constraints(
    assignments: List[Assignment], problem: SchedulingProblem, registry: ResourceRegistry
) -> List[dict]:
    room_violations: List[str] = []
    faculty_violations: List[str] = []
    group_violations: List[str] = []
    capacity_violations: List[str] = []
    room_type_violations: List[str] = []
    availability_violations: List[str] = []
    unavailability_violations: List[str] = []

    def label(a: Assignment) -> str:
        act = registry.get_activity(a.activity_id)
        code = act.course_code if act else a.activity_id
        return f"{code} ({a.day} {a.start})"

    for i in range(len(assignments)):
        for j in range(i + 1, len(assignments)):
            a, b = assignments[i], assignments[j]
            periods_a = set(a.periods)
            if a.day != b.day or not any(p in periods_a for p in b.periods):
                continue

            if a.room_id == b.room_id:
                room_violations.append(f"{label(a)} vs {label(b)} share room {a.room_id}")

            act_a = registry.get_activity(a.activity_id)
            act_b = registry.get_activity(b.activity_id)
            if act_a and act_b:
                shared = [f for f in act_a.faculty_ids if f in act_b.faculty_ids]
                if shared:
                    names = ", ".join(registry.faculty.get(f).name if registry.faculty.get(f) else f for f in shared)
                    faculty_violations.append(f"{label(a)} vs {label(b)} share faculty {names}")

                group_a = registry.groups.get(act_a.group_id)
                group_b = registry.groups.get(act_b.group_id)
                if group_a and group_b and groups_overlap(registry, act_a.group_id, act_b.group_id):
                    group_violations.append(f"{label(a)} vs {label(b)} share student group {group_a.division}")

    for a in assignments:
        act = registry.get_activity(a.activity_id)
        room = registry.get_room(a.room_id)
        if act is None or room is None:
            continue
        group = registry.groups.get(act.group_id)

        if group and room.capacity < group.size:
            capacity_violations.append(
                f"{label(a)}: {group.size} students exceed {room.id} capacity {room.capacity}"
            )

        needs_lab = act.session_type != "theory"
        if needs_lab and room.type != "laboratory":
            room_type_violations.append(f"{label(a)}: {act.session_type} session assigned to non-lab room {room.id}")
        if not needs_lab and room.type != "lecture-hall":
            room_type_violations.append(f"{label(a)}: theory session assigned to non-lecture-hall {room.id}")

        for fid in act.faculty_ids:
            for period in a.periods:
                if not registry.is_faculty_available(fid, slot_key(a.day, period)):
                    faculty = registry.faculty.get(fid)
                    name = faculty.name if faculty else fid
                    availability_violations.append(f"{label(a)}: {name} unavailable {a.day} {period}")
                for u in problem.unavailability:
                    if (
                        u.resource_type == "room"
                        and u.resource_id == a.room_id
                        and u.day == a.day
                        and u.period == period
                    ):
                        unavailability_violations.append(f"{label(a)}: room {a.room_id} unavailable {a.day} {period}")

    return [
        {"id": "HC-1", "label": "Room exclusivity — no room double-booked", "passed": len(room_violations) == 0, "violations": room_violations},
        {"id": "HC-2", "label": "Faculty exclusivity — no faculty teaching two classes simultaneously", "passed": len(faculty_violations) == 0, "violations": faculty_violations},
        {"id": "HC-3", "label": "Batch exclusivity — no batch attending two classes simultaneously", "passed": len(group_violations) == 0, "violations": group_violations},
        {"id": "HC-4", "label": "Room capacity — room holds the batch size", "passed": len(capacity_violations) == 0, "violations": capacity_violations},
        {"id": "HC-5", "label": "Room type — labs in laboratories, theory in lecture halls", "passed": len(room_type_violations) == 0, "violations": room_type_violations},
        {"id": "HC-6", "label": "Faculty availability — faculty free in assigned slot", "passed": len(availability_violations) == 0, "violations": availability_violations},
        {"id": "HC-7", "label": "Resource availability — no unavailable room assigned", "passed": len(unavailability_violations) == 0, "violations": unavailability_violations},
    ]


def compute_soft_score(
    assignments: List[Assignment], problem: SchedulingProblem, registry: ResourceRegistry
) -> dict:
    preference_hits = 0
    preference_total = 0

    for a in assignments:
        act = registry.get_activity(a.activity_id)
        if act is None:
            continue
        for fid in act.faculty_ids:
            preference_total += 1
            prefs = problem.faculty_preferences.get(fid)
            if prefs and any(slot_key(a.day, p) in prefs for p in a.periods):
                preference_hits += 1

    total_gaps = 0
    daily_loads: Dict[str, List[int]] = {}

    for a in assignments:
        act = registry.get_activity(a.activity_id)
        if act is None:
            continue
        for fid in act.faculty_ids:
            if fid not in daily_loads:
                daily_loads[fid] = [0] * len(problem.days)
            day_index = problem.days.index(a.day)
            daily_loads[fid][day_index] += act.duration

    for fid, loads in daily_loads.items():
        for day in problem.days:
            blocks = []
            for a in assignments:
                act = registry.get_activity(a.activity_id)
                if act is None or a.day != day or fid not in act.faculty_ids:
                    continue
                start_index = registry.slot_index(a.start)
                blocks.append((start_index, start_index + act.duration - 1))
            blocks.sort()
            for i in range(1, len(blocks)):
                if blocks[i][0] > blocks[i - 1][1] + 1:
                    total_gaps += blocks[i][0] - blocks[i - 1][1] - 1

    load_variance_sum = 0.0
    for loads in daily_loads.values():
        mean = sum(loads) / len(loads)
        load_variance_sum += sum((v - mean) ** 2 for v in loads) / len(loads)

    utilization_sum = 0.0
    for a in assignments:
        act = registry.get_activity(a.activity_id)
        room = registry.get_room(a.room_id)
        if act is None or room is None:
            continue
        group = registry.groups.get(act.group_id)
        if group:
            utilization_sum += min(1.0, group.size / room.capacity) * act.duration
    total_activity_hours = sum(
        (registry.get_activity(a.activity_id).duration if registry.get_activity(a.activity_id) else 0)
        for a in assignments
    )
    utilization = (utilization_sum / total_activity_hours) * 100 if total_activity_hours > 0 else 0.0

    faculty_preference = (preference_hits / preference_total) * 100 if preference_total > 0 else 0.0
    load_balance = load_variance_sum / max(1, len(daily_loads))

    return {
        "facultyPreference": round(faculty_preference, 1),
        "gapPenalty": total_gaps,
        "loadBalance": round(load_balance, 2),
        "roomUtilization": round(utilization, 1),
        "total": 0,
        "maxTotal": 100,
    }
