"""
Priority Queue — binary min-heap over lexicographic priority tuples.

Used by DSATUR to repeatedly extract the most constrained vertex
(highest saturation, then highest degree). Entries carry a monotonically
increasing counter so equal priorities pop in deterministic FIFO order.
Stale (outdated) entries are detected by the caller comparing the popped
priority against the vertex's current priority.
"""

import heapq
from typing import Generic, List, Optional, Tuple, TypeVar

T = TypeVar("T")

Entry = Tuple[tuple, int, T]  # (priority_tuple, counter, item)


class PriorityQueue(Generic[T]):
    def __init__(self) -> None:
        self._heap: List[Entry] = []
        self._counter = 0

    @property
    def size(self) -> int:
        return len(self._heap)

    def push(self, item: T, priority: tuple) -> None:
        heapq.heappush(self._heap, (priority, self._counter, item))
        self._counter += 1

    def pop(self) -> Optional[Tuple[T, tuple]]:
        if not self._heap:
            return None
        priority, _counter, item = heapq.heappop(self._heap)
        return item, priority
