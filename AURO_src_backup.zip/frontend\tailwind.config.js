/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#fdf4f5',
          100: '#fbe8eb',
          200: '#f8d5d9',
          300: '#f1b3bc',
          400: '#e58492',
          500: '#d45667',
          600: '#be394b',
          700: '#9f2b3b',
          800: '#842634',
          900: '#712430',
          950: '#3e0f16',
        },
        navy: {
          50: '#f0f5fa',
          100: '#e1eaf3',
          200: '#c3d5e7',
          300: '#95b7d6',
          400: '#6193c0',
          500: '#3c75a7',
          600: '#2c5d8a',
          700: '#244b70',
          800: '#213f5d',
          900: '#1f364e',
          950: '#142233',
        },
      },
      fontFamily: {
        sans: ['Plus Jakarta Sans', 'Inter', 'system-ui', 'sans-serif'],
        serif: ['Fraunces', 'Georgia', 'serif'],
        mono: ['JetBrains Mono', 'Menlo', 'monospace'],
      },
      boxShadow: {
        'glass': '0 8px 32px 0 rgba(31, 38, 135, 0.07)',
        'luminous': '0 10px 40px -10px rgba(190, 57, 75, 0.15)',
        'subtle': '0 2px 10px rgba(0, 0, 0, 0.04), 0 1px 3px rgba(0, 0, 0, 0.02)',
      },
    },
  },
  plugins: [],
};
