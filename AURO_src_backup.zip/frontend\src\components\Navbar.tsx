import React from 'react';
import { useAuth } from '../context/AuthContext';
import { RoleBadge } from './RoleBadge';
import { LogOut, MapPin, Orbit } from 'lucide-react';

export const Navbar: React.FC = () => {
  const { user, logout } = useAuth();

  if (!user) return null;

  return (
    <header className="sticky top-0 z-50 bg-[#FDFBF6]/92 border-b border-stone-200/90 backdrop-blur-md">
      <div className="px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3 lg:hidden">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-600 to-brand-800 flex items-center justify-center text-white">
            <Orbit className="w-5 h-5" />
          </div>
          <span className="font-serif font-black text-lg tracking-tight text-stone-900">AURO</span>
        </div>

        <div className="hidden lg:block">
          <div className="text-[10px] font-mono font-bold tracking-[0.22em] text-stone-400 uppercase">
            Autonomous University Resource Orchestrator
          </div>
          <div className="text-xs font-semibold text-stone-600 mt-0.5">
            Intelligent scheduling · Conflict detection · Minimal-displacement recovery
          </div>
        </div>

        <div className="flex items-center gap-3 sm:gap-4">
          <div className="hidden md:flex flex-col items-end text-right">
            <div className="text-xs font-bold text-stone-900 flex items-center gap-1.5">
              <span>{user.full_name}</span>
              {user.office_room && (
                <span className="text-[11px] font-normal text-stone-500 flex items-center gap-0.5">
                  <MapPin className="w-3 h-3 text-stone-400" />
                  {user.office_room}
                </span>
              )}
            </div>
            <div className="text-[11px] text-stone-500 font-mono">
              {user.email}
            </div>
          </div>

          <RoleBadge role={user.role} size="md" />

          <button
            onClick={logout}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-stone-700 hover:text-brand-700 bg-white/80 hover:bg-brand-50 border border-stone-200 hover:border-brand-200 transition-colors cursor-pointer"
            title="Sign Out"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>
        </div>
      </div>
    </header>
  );
};
