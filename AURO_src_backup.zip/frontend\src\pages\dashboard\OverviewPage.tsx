import React from 'react';
import {
  Brain,
  Database,
  Cpu,
  Globe,
  CheckCircle2,
  CircleDashed,
  ArrowRight,
  Layers3,
  Users,
  Building2,
  CalendarClock,
} from 'lucide-react';
import { FACULTY, ROOMS, buildSchedulingProblem } from '../../data/curriculum';
import { KLE_TIMETABLE_ENTRIES } from '../../data/timetableData';

const ENGINES = [
  {
    id: 'dsa',
    icon: Brain,
    weight: '35%',
    name: 'DSA Engine',
    subtitle: 'Scheduling Intelligence',
    status: 'IMPLEMENTED' as const,
    tone: 'emerald',
    capabilities: [
      'Conflict graph (vertices = sessions, edges = shared resources)',
      'DSATUR heuristic with max-heap priority queue',
      'CSP domains of feasible (slot, room) pairs',
      'Backtracking with forward checking + restoration',
      'Hard-constraint validator (HC-1 … HC-7)',
      'Soft-constraint optimizer & scoring',
    ],
    modules: ['graph/', 'dsatur/', 'csp/', 'generator/', 'core/'],
  },
  {
    id: 'dbms',
    icon: Database,
    weight: '25%',
    name: 'DBMS Engine',
    subtitle: 'Persistence & Integrity',
    status: 'PLANNED' as const,
    tone: 'stone',
    capabilities: [
      'PostgreSQL relational schema (19 tables)',
      'ACID transactions & optimistic locking',
      'Schedule versioning & audit logging',
      'Transactional notification outbox',
    ],
    modules: ['db/', 'repositories/', 'migrations/'],
  },
  {
    id: 'os',
    icon: Cpu,
    weight: '20%',
    name: 'OS Engine',
    subtitle: 'Job Coordination',
    status: 'PLANNED' as const,
    tone: 'stone',
    capabilities: [
      'Multiprocessing worker pool',
      'Priority job queue with dynamic aging',
      'IPC message queues between processes',
      'Deadlock prevention (Havender)',
    ],
    modules: ['os_engine/', 'worker_pool/', 'ipc/'],
  },
  {
    id: 'web',
    icon: Globe,
    weight: '20%',
    name: 'Web & Networks',
    subtitle: 'Interface & Comms',
    status: 'ACTIVE' as const,
    tone: 'blue',
    capabilities: [
      'React 18 + TypeScript + Tailwind portal',
      'FastAPI REST APIs & JWT authentication',
      'Real-time WebSocket events',
      'Backend RBAC for all roles',
    ],
    modules: ['pages/', 'components/', 'context/'],
  },
];

const PIPELINE = [
  { label: 'Conflict Graph', detail: 'O(n²) edge construction' },
  { label: 'DSATUR', detail: 'saturation-ordered colouring' },
  { label: 'CSP Domains', detail: 'feasible (day, slot, room)' },
  { label: 'Backtracking + FC', detail: 'search with domain pruning' },
  { label: 'Hard Validation', detail: 'HC-1 … HC-7 checks' },
  { label: 'Soft Scoring', detail: 'objective optimisation' },
];

const statusStyle = (status: string) => {
  switch (status) {
    case 'IMPLEMENTED':
      return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    case 'ACTIVE':
      return 'bg-blue-50 text-blue-700 border-blue-200';
    default:
      return 'bg-stone-100 text-stone-500 border-stone-200';
  }
};

export const OverviewPage: React.FC<{ onOpenEngine: () => void }> = ({ onOpenEngine }) => {
  const problem = buildSchedulingProblem();

  const stats = [
    { icon: Users, label: 'Faculty Members', value: FACULTY.length },
    { icon: Building2, label: 'Rooms & Laboratories', value: ROOMS.length },
    { icon: Layers3, label: 'Scheduling Activities', value: problem.activities.length },
    { icon: CalendarClock, label: 'Timetable Entries (Benchmark)', value: KLE_TIMETABLE_ENTRIES.length },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Hero */}
      <div className="relative rounded-2xl border border-stone-300 bg-[#FDFBF6] overflow-hidden">
        <div className="absolute inset-0 bg-paper-grid opacity-60 pointer-events-none" />
        <div className="relative px-6 sm:px-8 py-8">
          <div className="font-mono text-[10px] font-bold tracking-[0.25em] text-brand-700">
            AURO · AUTONOMOUS UNIVERSITY RESOURCE ORCHESTRATOR
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl font-black tracking-tight text-stone-900 mt-2">
            Command Center
          </h1>
          <p className="text-sm text-stone-600 leading-relaxed max-w-2xl mt-3">
            AURO automates academic timetable generation, detects resource conflicts, simulates
            what-if disruptions, and executes minimal-displacement schedule recovery — powered by
            four integrated engineering engines.
          </p>
          <div className="flex flex-wrap items-center gap-2 mt-5">
            <button
              onClick={onOpenEngine}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-brand-700 to-brand-800 text-white text-xs font-bold tracking-wide shadow-sm hover:shadow-md hover:-translate-y-px transition-all cursor-pointer"
            >
              <Brain className="w-4 h-4" />
              Open Timetable Engine
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <span className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-stone-200 text-[11px] font-mono font-bold text-stone-500">
              MODE A · INITIAL GENERATION
            </span>
          </div>
        </div>
      </div>

      {/* Campus stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="bg-white rounded-xl border border-stone-200 p-4 shadow-2xs">
              <div className="flex items-center gap-2 text-[11px] font-semibold text-stone-500 uppercase tracking-wide">
                <Icon className="w-3.5 h-3.5 text-brand-700" />
                {s.label}
              </div>
              <div className="font-serif text-2xl font-black text-stone-900 mt-2">{s.value}</div>
            </div>
          );
        })}
      </div>

      {/* Four engines */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-serif text-xl font-black text-stone-900">The Four-Engine Architecture</h2>
          <span className="text-[10px] font-mono tracking-[0.2em] text-stone-400">FOUR ENGINEERING DOMAINS · ONE ORCHESTRATOR</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {ENGINES.map((engine) => {
            const Icon = engine.icon;
            return (
              <div
                key={engine.id}
                className={`rounded-2xl border p-5 shadow-2xs bg-[#FDFBF6] ${
                  engine.status === 'PLANNED' ? 'border-stone-200 opacity-90' : 'border-stone-300'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white border border-stone-200 flex items-center justify-center">
                      <Icon className={`w-5 h-5 ${engine.status === 'PLANNED' ? 'text-stone-400' : 'text-brand-700'}`} />
                    </div>
                    <div>
                      <div className="font-serif font-black text-stone-900">{engine.name}</div>
                      <div className="text-[11px] text-stone-500 font-medium">{engine.subtitle}</div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1.5">
                    <span className="text-[10px] font-mono font-black text-stone-400">{engine.weight}</span>
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold tracking-widest border ${statusStyle(engine.status)}`}>
                      {engine.status === 'PLANNED' ? <CircleDashed className="w-3 h-3" /> : <CheckCircle2 className="w-3 h-3" />}
                      {engine.status}
                    </span>
                  </div>
                </div>

                <ul className="mt-4 space-y-1.5">
                  {engine.capabilities.map((c) => (
                    <li key={c} className="flex items-start gap-2 text-[11.5px] text-stone-600 font-medium">
                      <span className={`w-1 h-1 rounded-full mt-1.5 shrink-0 ${engine.status === 'PLANNED' ? 'bg-stone-300' : 'bg-brand-600'}`} />
                      {c}
                    </li>
                  ))}
                </ul>

                <div className="mt-4 pt-3 border-t border-stone-100 flex flex-wrap gap-1.5">
                  {engine.modules.map((m) => (
                    <span key={m} className="text-[9px] font-mono font-bold bg-stone-100 text-stone-500 px-1.5 py-0.5 rounded border border-stone-200">
                      {m}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* DSA pipeline */}
      <div className="rounded-2xl border border-stone-300 bg-[#FDFBF6] p-6">
        <div className="font-mono text-[10px] font-bold tracking-[0.25em] text-brand-700">
          DSA ENGINE · GENERATION PIPELINE
        </div>
        <div className="flex flex-wrap items-center gap-2 mt-4">
          {PIPELINE.map((step, i) => (
            <React.Fragment key={step.label}>
              <div className="px-3 py-2 rounded-xl bg-white border border-stone-200 shadow-2xs">
                <div className="text-xs font-bold text-stone-800">{step.label}</div>
                <div className="text-[9.5px] font-mono text-stone-400 mt-0.5">{step.detail}</div>
              </div>
              {i < PIPELINE.length - 1 && <ArrowRight className="w-4 h-4 text-stone-300 shrink-0" />}
            </React.Fragment>
          ))}
        </div>
        <p className="text-[11px] text-stone-500 mt-4 leading-relaxed">
          Hard constraints are validated independently and are never traded away for a better
          soft-constraint score. If no feasible schedule exists, AURO reports unresolved conflicts
          rather than emitting an invalid timetable.
        </p>
      </div>
    </div>
  );
};
