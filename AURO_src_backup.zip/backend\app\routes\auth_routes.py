"""
/auth routes — login, session introspection, logout.
"""

from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel

from ..auth import get_current_user, token_from_header
from ..data.users import verify_password
from ..services.store import session_store

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


class LoginRequest(BaseModel):
    email: str
    password: str


@router.post("/login")
def login(body: LoginRequest):
    record = verify_password(body.email, body.password)
    if record is None:
        raise HTTPException(status_code=401, detail="Invalid email or password.")
    token = session_store.create(record)
    return {"access_token": token, "token_type": "bearer", "user": record}


@router.get("/me")
def me(user: dict = Depends(get_current_user)):
    return user


@router.post("/logout")
def logout(
    user: dict = Depends(get_current_user),
    authorization: Optional[str] = Header(default=None),
):
    session_store.revoke(token_from_header(authorization))
    return {"detail": "Logged out."}
