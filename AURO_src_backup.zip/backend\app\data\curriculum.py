"""
CSE Semester V curriculum data — the live problem instance for AURO.

Same dataset as the reference benchmark: 23 faculty, 8 rooms,
12 student groups (4 divisions x {FULL, B1, B2}), ~77 schedulable
activities including 3h/4h lab blocks and mini-project evaluations.
"""

from typing import Dict, List, Optional, Set

from ..engine.core.types import (
    Activity,
    Day,
    Division,
    Faculty,
    PeriodId,
    Room,
    SchedulingProblem,
    StudentGroup,
    TimeSlot,
    Unavailability,
)

TIME_SLOTS: List[TimeSlot] = [
    TimeSlot("P1", 0, "08:00", "09:00", "Period 1"),
    TimeSlot("P2", 1, "09:00", "10:00", "Period 2"),
    TimeSlot("P3", 2, "10:30", "11:30", "Period 3"),
    TimeSlot("P4", 3, "11:30", "12:30", "Period 4"),
    TimeSlot("P5", 4, "01:30", "02:30", "Period 5"),
    TimeSlot("P6", 5, "02:30", "03:30", "Period 6"),
    TimeSlot("P7", 6, "03:30", "04:30", "Period 7"),
    TimeSlot("P8", 7, "04:30", "05:30", "Period 8"),
]

DAYS: List[Day] = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

ROOMS: List[Room] = [
    Room("step-hall", "Step Hall", "lecture-hall", 130, "Main Building Block A"),
    Room("mb204", "MB204", "lecture-hall", 130, "Main Building Block A"),
    Room("mb208", "MB208", "lecture-hall", 130, "Main Building Block A"),
    Room("ai-room", "AI Room", "lecture-hall", 130, "CS Wing"),
    Room("project-lab", "Project Lab", "laboratory", 130, "CS Wing"),
    Room("network-lab", "Network Lab", "laboratory", 65, "CS Wing"),
    Room("dl-gpu-lab", "DL GPU Lab", "laboratory", 65, "Advanced Computing Center"),
    Room("embedded-lab", "Embedded Lab", "laboratory", 65, "Electronics Wing"),
]


def _f(fid: str, name: str, designation: str, unavailable: Optional[List[str]] = None,
       preferred: Optional[List[str]] = None) -> Faculty:
    return Faculty(fid, name, designation, unavailable or [], preferred or [])


FACULTY: List[Faculty] = [
    _f("salma", "Dr. Salma Shahapur", "Associate Professor", ["Sat:P1", "Sat:P2"], ["Mon:P3", "Tue:P3", "Wed:P3"]),
    _f("tabassum", "Tabassum J", "Assistant Professor", [], ["Mon:P1", "Tue:P1"]),
    _f("prema", "Dr. Prema T. A.", "Professor", [], ["Mon:P3", "Wed:P3"]),
    _f("swati", "Swati S", "Lab Instructor"),
    _f("somanatti", "U. V. Somanatti", "Associate Professor", [], ["Mon:P3", "Tue:P3"]),
    _f("neha", "Neha Nimbalkar", "Assistant Professor"),
    _f("sakshi", "Sakshi S", "Lab Instructor"),
    _f("ryan", "Dr. Ryan Dias", "Assistant Professor", ["Sat:P5", "Sat:P6", "Sat:P7"], ["Mon:P1", "Fri:P1"]),
    _f("madhu", "Madhu S", "Lab Instructor"),
    _f("aarya", "Aarya G", "Lab Instructor"),
    _f("amey", "Amey Muchandi", "Assistant Professor", [], ["Mon:P2", "Tue:P2"]),
    _f("akshata", "Akshata P", "Lab Instructor"),
    _f("supriya_n", "Supriya N", "Lab Instructor"),
    _f("niranjan", "Dr. Niranjan Muchandi", "Professor"),
    _f("santosh", "Dr. Santosh Pattar", "Associate Professor",
       ["Sat:P1", "Sat:P2", "Sat:P3", "Sat:P4", "Sat:P5", "Sat:P6", "Sat:P7"], ["Mon:P5", "Tue:P5"]),
    _f("ashwini", "Ashwini B", "Lab Instructor", ["Sat:P5"]),
    _f("sushmita", "Sushmita P", "Assistant Professor"),
    _f("soumya", "Soumya M", "Lab Instructor"),
    _f("khanai", "Dr. Rajashri Khanai", "Professor & HOD", ["Sat:P1", "Sat:P2"], ["Fri:P5"]),
    _f("madhurani", "Madhurani S", "Assistant Professor"),
    _f("shrigouri", "Shrigouri M", "Lab Instructor"),
    _f("belkar", "Supriya Belkar", "Assistant Professor"),
    _f("priyanka_patil", "Priyanka Patil", "Assistant Professor"),
]

STUDENT_GROUPS: List[StudentGroup] = [
    StudentGroup("div-A", "A", "FULL", 120),
    StudentGroup("div-A-B1", "A", "B1", 60),
    StudentGroup("div-A-B2", "A", "B2", 60),
    StudentGroup("div-B", "B", "FULL", 120),
    StudentGroup("div-B-B1", "B", "B1", 60),
    StudentGroup("div-B-B2", "B", "B2", 60),
    StudentGroup("div-C", "C", "FULL", 120),
    StudentGroup("div-C-B1", "C", "B1", 60),
    StudentGroup("div-C-B2", "C", "B2", 60),
    StudentGroup("div-D", "D", "FULL", 80),
    StudentGroup("div-D-B1", "D", "B1", 40),
    StudentGroup("div-D-B2", "D", "B2", 40),
]

DIVISION_HALL: Dict[Division, str] = {"A": "step-hall", "B": "mb204", "C": "mb208", "D": "ai-room"}


class _Lab:
    def __init__(self, duration: int, room_ids: List[str], group_id: str,
                 faculty_ids: List[str], session_type: str = "lab") -> None:
        self.duration = duration
        self.room_ids = room_ids
        self.group_id = group_id
        self.faculty_ids = faculty_ids
        self.session_type = session_type


class _MiniProject:
    def __init__(self, duration: int, room_id: str, faculty_ids: List[str]) -> None:
        self.duration = duration
        self.room_id = room_id
        self.faculty_ids = faculty_ids


class Offering:
    def __init__(self, division: Division, course_code: str, course_title: str,
                 faculty_ids: List[str], theory_sessions: int,
                 labs: Optional[List[_Lab]] = None,
                 mini_project: Optional[_MiniProject] = None) -> None:
        self.division = division
        self.course_code = course_code
        self.course_title = course_title
        self.faculty_ids = faculty_ids
        self.theory_sessions = theory_sessions
        self.labs = labs or []
        self.mini_project = mini_project


OFFERINGS: List[Offering] = [
    Offering("A", "25ECSC309", "Deep Learning", ["salma"], 3,
             [_Lab(3, ["dl-gpu-lab"], "div-A-B1", ["salma", "tabassum", "swati"])]),
    Offering("A", "25ECSC304", "Cryptography & Network Security", ["somanatti"], 3,
             [_Lab(2, ["network-lab"], "div-A-B1", ["somanatti", "sakshi"])]),
    Offering("A", "26ECSC313", "Microcontroller & Embedded Systems", ["amey"], 3,
             [_Lab(2, ["embedded-lab"], "div-A-B1", ["amey", "akshata", "supriya_n"])]),
    Offering("A", "26ECSC312", "Wireless & Mobile Networks", ["ryan"], 2,
             [_Lab(2, ["network-lab"], "div-A-B2", ["ryan", "madhu", "aarya"])]),
    Offering("A", "25ECSE347", "Cyber Security", ["sushmita"], 2,
             [_Lab(2, ["network-lab"], "div-A-B2", ["sushmita", "soumya"])]),
    Offering("A", "26ECSE346", "AI Assisted Software Development", ["santosh"], 1,
             [_Lab(4, ["project-lab", "dl-gpu-lab"], "div-A-B1", ["santosh", "ashwini"])]),
    Offering("A", "23EHSA303", "ATAR Soft Skills", ["priyanka_patil"], 1),
    Offering("A", "25ECSW301", "Mini Project Evaluation", ["khanai"], 0,
             mini_project=_MiniProject(3, "project-lab", ["khanai"])),
    Offering("B", "25ECSC309", "Deep Learning", ["tabassum"], 3,
             [_Lab(2, ["dl-gpu-lab"], "div-B-B1", ["tabassum", "salma", "swati"])]),
    Offering("B", "25ECSC304", "Cryptography & Network Security", ["neha"], 3,
             [_Lab(2, ["network-lab"], "div-B-B2", ["neha", "sakshi"])]),
    Offering("B", "26ECSC313", "Microcontroller & Embedded Systems", ["amey"], 3,
             [_Lab(2, ["embedded-lab"], "div-B-B1", ["amey", "akshata", "ashwini"])]),
    Offering("B", "26ECSC312", "Wireless & Mobile Networks", ["madhurani"], 2),
    Offering("B", "25ECSE347", "Cyber Security", ["sushmita"], 2),
    Offering("B", "26ECSE346", "AI Assisted Software Development", ["santosh"], 0,
             [_Lab(4, ["project-lab", "dl-gpu-lab"], "div-B-B2", ["santosh", "ashwini"])]),
    Offering("B", "23EHSA303", "ATAR Soft Skills", ["priyanka_patil"], 1),
    Offering("B", "25ECSW301", "Mini Project Evaluation", ["sushmita"], 0,
             mini_project=_MiniProject(3, "project-lab", ["sushmita"])),
    Offering("C", "25ECSC309", "Deep Learning", ["tabassum"], 3,
             [_Lab(3, ["dl-gpu-lab"], "div-C-B2", ["tabassum", "prema", "swati"])]),
    Offering("C", "25ECSC304", "Cryptography & Network Security", ["neha"], 3),
    Offering("C", "26ECSC313", "Microcontroller & Embedded Systems", ["niranjan"], 3,
             [_Lab(2, ["embedded-lab"], "div-C-B1", ["niranjan", "akshata", "belkar"])]),
    Offering("C", "26ECSC312", "Wireless & Mobile Networks", ["belkar"], 2),
    Offering("C", "25ECSE347", "Cyber Security", ["sushmita"], 2,
             [_Lab(2, ["network-lab"], "div-C-B1", ["sushmita", "soumya"])]),
    Offering("C", "26ECSE346", "AI Assisted Software Development", ["santosh"], 0,
             [_Lab(4, ["project-lab", "dl-gpu-lab"], "div-C-B2", ["santosh", "ashwini"])]),
    Offering("C", "23EHSA303", "ATAR Soft Skills", ["priyanka_patil"], 1),
    Offering("C", "25ECSW301", "Mini Project Evaluation", ["niranjan"], 0,
             mini_project=_MiniProject(3, "project-lab", ["niranjan"])),
    Offering("D", "26ECAC301", "Cloud Computing", ["madhurani"], 3,
             [_Lab(2, ["network-lab"], "div-D-B1", ["madhurani", "shrigouri"])]),
    Offering("D", "26ECAC304", "Parallel & GPU Computing", ["santosh"], 3,
             [_Lab(2, ["dl-gpu-lab"], "div-D-B1", ["santosh", "ashwini"])]),
    Offering("D", "26ECAC302", "Deep Learning", ["prema"], 3,
             [_Lab(3, ["dl-gpu-lab"], "div-D-B2", ["prema", "salma", "swati"])]),
    Offering("D", "26ECAC305", "Cryptography & Network Security", ["somanatti"], 2),
    Offering("D", "26ECSE346", "AI Assisted Software Development", ["santosh"], 1),
    Offering("D", "23EHSA303", "ATAR Soft Skills", ["priyanka_patil"], 1),
    Offering("D", "22ECAW301", "Mini Project Evaluation", ["amey"], 0,
             mini_project=_MiniProject(3, "project-lab", ["amey"])),
]

UNAVAILABILITY: List[Unavailability] = [
    Unavailability("project-lab", "room", "Sat", "P1"),
    Unavailability("project-lab", "room", "Sat", "P2"),
    Unavailability("dl-gpu-lab", "room", "Mon", "P1"),
]


def build_scheduling_problem() -> SchedulingProblem:
    activities: List[Activity] = []

    for offering in OFFERINGS:
        hall = DIVISION_HALL[offering.division]

        for s in range(1, offering.theory_sessions + 1):
            activities.append(Activity(
                id=f"{offering.division}-{offering.course_code}-T{s}",
                course_code=offering.course_code,
                course_title=offering.course_title,
                faculty_ids=list(offering.faculty_ids),
                group_id=f"div-{offering.division}",
                duration=1,
                session_type="theory",
                allowed_room_ids=[hall],
            ))

        for idx, lab in enumerate(offering.labs):
            activities.append(Activity(
                id=f"{offering.division}-{offering.course_code}-L{idx + 1}",
                course_code=offering.course_code,
                course_title=f"{offering.course_title} Lab",
                faculty_ids=list(lab.faculty_ids),
                group_id=lab.group_id,
                duration=lab.duration,
                session_type=lab.session_type,
                allowed_room_ids=list(lab.room_ids),
            ))

        if offering.mini_project:
            mp = offering.mini_project
            activities.append(Activity(
                id=f"{offering.division}-{offering.course_code}-MP",
                course_code=offering.course_code,
                course_title=offering.course_title,
                faculty_ids=list(mp.faculty_ids),
                group_id=f"div-{offering.division}",
                duration=mp.duration,
                session_type="project",
                allowed_room_ids=[mp.room_id],
            ))

    faculty_availability: Dict[str, Dict[str, bool]] = {}
    for f in FACULTY:
        faculty_availability[f.id] = {
            f"{day}:{slot.id}": f"{day}:{slot.id}" not in f.unavailable_slots
            for day in DAYS
            for slot in TIME_SLOTS
        }

    faculty_preferences: Dict[str, Set[str]] = {f.id: set(f.preferred_slots) for f in FACULTY}

    return SchedulingProblem(
        days=DAYS,
        slots=TIME_SLOTS,
        rooms=ROOMS,
        faculty=FACULTY,
        groups=STUDENT_GROUPS,
        activities=activities,
        faculty_availability=faculty_availability,
        faculty_preferences=faculty_preferences,
        unavailability=UNAVAILABILITY,
    )
