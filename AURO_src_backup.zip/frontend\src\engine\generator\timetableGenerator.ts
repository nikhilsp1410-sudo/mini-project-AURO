import { ResourceRegistry } from '../core/registry';
import { Assignment, GenerationResult, SchedulingProblem, SearchMetrics } from '../core/types';
import { ConflictGraph } from '../graph/ConflictGraph';
import { runDsatur } from '../dsatur/dsatur';
import { buildDomains } from '../csp/domains';
import { computeSoftScore, validateHardConstraints } from '../csp/constraints';
import { solveWithBacktracking } from '../csp/backtracking';

export const generateTimetable = (problem: SchedulingProblem): GenerationResult => {
  const t0 = performance.now();

  const registry = new ResourceRegistry(problem);
  const graph = ConflictGraph.build(problem.activities);
  const dsatur = runDsatur(graph);
  const domains = buildDomains(problem);

  const emptyDomainActivities = Array.from(domains.entries())
    .filter(([, v]) => v.length === 0)
    .map(([k]) => k);

  const solve = solveWithBacktracking(problem, dsatur.order, domains, graph, registry);
  const elapsed = performance.now() - t0;

  const edgesByReason = graph.edgesByReason;
  const degrees = Array.from(graph.vertices.keys()).map((id) => graph.getDegree(id));
  const vertexCount = graph.vertices.size;

  const metrics: SearchMetrics = {
    vertices: vertexCount,
    edges: graph.edgeCount,
    graphDensity: vertexCount > 1 ? Number(((2 * graph.edgeCount) / (vertexCount * (vertexCount - 1))).toFixed(3)) : 0,
    edgesByReason,
    maxDegree: degrees.length > 0 ? Math.max(...degrees) : 0,
    averageDegree: degrees.length > 0 ? Number((degrees.reduce((s, v) => s + v, 0) / degrees.length).toFixed(1)) : 0,
    dsaturOrderFirst: dsatur.order.slice(0, 12),
    iterations: solve.metrics.iterations,
    backtracks: solve.metrics.backtracks,
    prunes: solve.metrics.prunes,
    maxDepth: solve.metrics.maxDepth,
    elapsedMs: Number(elapsed.toFixed(1)),
    solved: solve.assignments !== null,
  };

  const assignments: Assignment[] = solve.assignments ?? [];
  const hardValidation = validateHardConstraints(assignments, problem, registry);
  const softScore = computeSoftScore(assignments, problem, registry);
  softScore.total = Number(
    (softScore.facultyPreference - softScore.gapPenalty * 4 - softScore.loadBalance * 3 + softScore.roomUtilization * 0.6).toFixed(1)
  );

  void emptyDomainActivities;

  return {
    assignments,
    metrics,
    hardValidation,
    softScore,
    generatedAt: new Date().toLocaleString(),
  };
};
