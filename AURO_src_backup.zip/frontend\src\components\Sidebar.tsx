import React from 'react';
import { Orbit, LayoutDashboard, CalendarCog, BookMarked } from 'lucide-react';

export type NavTab = 'overview' | 'generator' | 'reference';

const TABS: Array<{ id: NavTab; label: string; sub: string; icon: React.ElementType }> = [
  { id: 'overview', label: 'Command Center', sub: 'Project overview & engines', icon: LayoutDashboard },
  { id: 'generator', label: 'Timetable Engine', sub: 'DSA · generate schedules', icon: CalendarCog },
  { id: 'reference', label: 'Reference Benchmark', sub: 'KLE ground-truth grids', icon: BookMarked },
];

export const Sidebar: React.FC<{ active: NavTab; onNavigate: (tab: NavTab) => void }> = ({ active, onNavigate }) => {
  return (
    <aside className="hidden lg:flex w-64 shrink-0 flex-col border-r border-stone-200 bg-[#FDFBF6]/95 backdrop-blur-md">
      <div className="px-5 py-5 border-b border-stone-200 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-600 to-brand-800 flex items-center justify-center text-white shadow-sm ring-1 ring-brand-900/20">
          <Orbit className="w-5 h-5" />
        </div>
        <div>
          <div className="font-serif font-black text-lg tracking-tight text-stone-900 leading-none">AURO</div>
          <div className="text-[9px] font-mono tracking-[0.18em] text-stone-400 mt-1">RESOURCE ORCHESTRATOR</div>
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = active === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onNavigate(tab.id)}
              className={`w-full text-left px-3 py-2.5 rounded-xl flex items-start gap-3 transition-all cursor-pointer ${
                isActive
                  ? 'bg-brand-50 border border-brand-200 text-brand-800'
                  : 'border border-transparent text-stone-600 hover:bg-stone-100/80 hover:text-stone-900'
              }`}
            >
              <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${isActive ? 'text-brand-700' : 'text-stone-400'}`} />
              <span>
                <span className="block text-xs font-bold">{tab.label}</span>
                <span className={`block text-[10px] font-medium mt-0.5 ${isActive ? 'text-brand-600' : 'text-stone-400'}`}>
                  {tab.sub}
                </span>
              </span>
            </button>
          );
        })}
      </nav>

      <div className="px-5 py-4 border-t border-stone-200">
        <div className="text-[9px] font-mono tracking-[0.18em] text-stone-400 leading-relaxed">
          CONFLICT GRAPH · DSATUR · CSP
          <br />
          BACKTRACKING + FORWARD CHECKING
        </div>
      </div>
    </aside>
  );
};
