export interface PQEntry<T> {
  item: T;
  priority: number[];
}

export class PriorityQueue<T> {
  private heap: Array<{ priority: number[]; counter: number; item: T }> = [];
  private counter = 0;

  get size(): number {
    return this.heap.length;
  }

  push(item: T, priority: number[]): void {
    this.heap.push({ priority, counter: this.counter++, item });
    this.siftUp(this.heap.length - 1);
  }

  pop(): PQEntry<T> | undefined {
    if (this.heap.length === 0) return undefined;
    const top = this.heap[0];
    const last = this.heap.pop()!;
    if (this.heap.length > 0) {
      this.heap[0] = last;
      this.siftDown(0);
    }
    return { item: top.item, priority: top.priority };
  }

  private siftUp(i: number): void {
    while (i > 0) {
      const parent = (i - 1) >> 1;
      if (this.compare(this.heap[i], this.heap[parent]) < 0) {
        [this.heap[i], this.heap[parent]] = [this.heap[parent], this.heap[i]];
        i = parent;
      } else break;
    }
  }

  private siftDown(i: number): void {
    const n = this.heap.length;
    while (true) {
      const l = 2 * i + 1;
      const r = 2 * i + 2;
      let smallest = i;
      if (l < n && this.compare(this.heap[l], this.heap[smallest]) < 0) smallest = l;
      if (r < n && this.compare(this.heap[r], this.heap[smallest]) < 0) smallest = r;
      if (smallest === i) break;
      [this.heap[i], this.heap[smallest]] = [this.heap[smallest], this.heap[i]];
      i = smallest;
    }
  }

  private compare(a: { priority: number[]; counter: number }, b: { priority: number[]; counter: number }): number {
    const len = Math.min(a.priority.length, b.priority.length);
    for (let i = 0; i < len; i++) {
      if (a.priority[i] !== b.priority[i]) return a.priority[i] - b.priority[i];
    }
    return a.counter - b.counter;
  }
}
