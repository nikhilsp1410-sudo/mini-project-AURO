import React from 'react';
import { UserRole } from '../types/auth';

interface RoleBadgeProps {
  role: UserRole;
  size?: 'sm' | 'md';
}

export const RoleBadge: React.FC<RoleBadgeProps> = ({ role, size = 'md' }) => {
  const getBadgeStyle = () => {
    switch (role) {
      case 'admin':
        return 'bg-rose-50 text-rose-800 border-rose-200';
      case 'coordinator':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'faculty':
        return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      case 'student':
        return 'bg-sky-50 text-sky-800 border-sky-200';
      default:
        return 'bg-stone-100 text-stone-800 border-stone-200';
    }
  };

  const getLabel = () => {
    switch (role) {
      case 'admin':
        return 'Dean / Admin';
      case 'coordinator':
        return 'Timetable Officer';
      case 'faculty':
        return 'Faculty Member';
      case 'student':
        return 'Student';
    }
  };

  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs';

  return (
    <span
      className={`inline-flex items-center font-bold font-mono rounded-md border ${sizeClasses} ${getBadgeStyle()}`}
    >
      {getLabel()}
    </span>
  );
};
