"""
Backtracking search with Forward Checking (MRV variable ordering).

- MRV: always branch on the unassigned activity with the fewest feasible
  values; DSATUR's ordering breaks ties deterministically.
- Forward checking: after each assignment, prune conflicting values from
  neighbouring domains. Pruning is resource-aware — a value is removed
  only when it truly conflicts with the new assignment (same room, or
  shared faculty, or overlapping student groups) at an overlapping time.
- Domains are restored on backtrack; the busy-slot state is undone in
  lockstep, so the state is always consistent with `assignment`.

Search budget: MAX_ITERATIONS value attempts.
"""

from typing import Dict, List, Optional, Set, Tuple

from ..core.registry import ResourceRegistry
from ..core.types import Assignment, DomainValue, SchedulingProblem
from ..graph.conflict_graph import ConflictGraph
from .constraints import SolverState, assign, groups_overlap, unassign, value_conflicts

MAX_ITERATIONS = 400_000


def solve_with_backtracking(
    problem: SchedulingProblem,
    order: List[str],
    domains_template: Dict[str, List[DomainValue]],
    graph: ConflictGraph,
    registry: ResourceRegistry,
) -> dict:
    domains: Dict[str, List[DomainValue]] = {
        activity_id: list(domains_template.get(activity_id, [])) for activity_id in order
    }
    state = SolverState()
    assignment: Dict[str, DomainValue] = {}
    metrics = {"iterations": 0, "backtracks": 0, "prunes": 0, "maxDepth": 0}

    day_index = {day: i for i, day in enumerate(problem.days)}

    def sort_key(value: DomainValue) -> Tuple[int, int]:
        return (day_index[value.day], registry.slot_index(value.start))

    def backtrack(depth: int) -> bool:
        if len(assignment) == len(order):
            return True
        if metrics["iterations"] > MAX_ITERATIONS:
            return False
        metrics["iterations"] += 1
        metrics["maxDepth"] = max(metrics["maxDepth"], depth)

        current: Optional[str] = None
        best_feasibility = float("inf")
        for activity_id in order:
            if activity_id in assignment:
                continue
            feasible_count = len(domains[activity_id])
            if feasible_count < best_feasibility:
                best_feasibility = feasible_count
                current = activity_id
                if feasible_count == 0:
                    break
        if current is None:
            return False

        activity = registry.get_activity(current)
        if activity is None:
            return False
        values = sorted(domains[current], key=sort_key)

        for value in values:
            metrics["iterations"] += 1
            if metrics["iterations"] > MAX_ITERATIONS:
                return False

            overlapping = _overlapping_groups(activity.group_id)
            if value_conflicts(state, value, activity.faculty_ids, activity.group_id, overlapping):
                continue

            assign(state, value, activity.faculty_ids, activity.group_id)
            assignment[current] = value

            saved_domains: List[Tuple[str, List[DomainValue]]] = []
            feasible = True

            for neighbor in graph.get_neighbors(current):
                if neighbor in assignment:
                    continue
                neighbor_activity = registry.get_activity(neighbor)
                if neighbor_activity is None:
                    continue
                shares_faculty = any(f in neighbor_activity.faculty_ids for f in activity.faculty_ids)
                shares_group = groups_overlap(registry, activity.group_id, neighbor_activity.group_id)

                before = domains[neighbor]
                after = [
                    v for v in before
                    if not _prunes(v, value, shares_faculty, shares_group)
                ]
                if len(after) != len(before):
                    saved_domains.append((neighbor, before))
                    domains[neighbor] = after
                    if not after:
                        feasible = False
                        break

            if feasible and backtrack(depth + 1):
                return True

            del assignment[current]
            unassign(state, value, activity.faculty_ids, activity.group_id)
            for neighbor_id, saved in saved_domains:
                domains[neighbor_id] = saved
            if saved_domains:
                metrics["prunes"] += 1
            metrics["backtracks"] += 1

            if metrics["iterations"] > MAX_ITERATIONS:
                return False

        return False

    group_overlap_cache: Dict[str, List[str]] = {}

    def _overlapping_groups(group_id: str) -> List[str]:
        if group_id in group_overlap_cache:
            return group_overlap_cache[group_id]
        result: List[str] = []
        for g in registry.groups.values():
            if groups_overlap(registry, group_id, g.id):
                result.append(g.id)
        group_overlap_cache[group_id] = result
        return result

    solved = backtrack(0)

    assignments: List[Assignment] = []
    if solved:
        for activity_id, value in assignment.items():
            assignments.append(
                Assignment(activity_id, value.day, value.start, value.room_id, value.periods)
            )

    return {"assignments": assignments if solved else None, "metrics": metrics}


def _prunes(value: DomainValue, assigned: DomainValue, shares_faculty: bool, shares_group: bool) -> bool:
    """Resource-aware forward-check prune: only remove the candidate value
    when it conflicts with the assigned value on a shared resource."""
    if value.day != assigned.day:
        return False
    assigned_periods = set(assigned.periods)
    if not any(p in assigned_periods for p in value.periods):
        return False
    if value.room_id == assigned.room_id:
        return True
    if shares_faculty:
        return True
    if shares_group:
        return True
    return False
