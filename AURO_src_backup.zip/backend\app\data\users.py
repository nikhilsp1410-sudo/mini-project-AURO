"""
Demo user database with role-based profiles.

Roles: admin | coordinator | faculty | student. Each profile carries the
fields the frontend needs to render that role's dashboard (faculty_id
links a teacher to engine faculty ids; division/batch link a student to
a student group).
"""

import hashlib
from typing import Dict, Optional

ROLE_ADMIN = "admin"
ROLE_COORDINATOR = "coordinator"
ROLE_FACULTY = "faculty"
ROLE_STUDENT = "student"

_SALT = "auro-static-salt::"

_USERS: list = [
    {
        "user_id": "usr-admin-001", "email": "admin@auro.edu", "password": "admin123",
        "full_name": "Dr. Praveen A. Ghorpade", "role": ROLE_ADMIN,
        "department_name": "Academic Affairs & Senate",
        "designation": "Professor & Dean Academics",
        "office_room": "Admin Block, Room 201",
    },
    {
        "user_id": "usr-admin-002", "email": "hod.cse@auro.edu", "password": "admin123",
        "full_name": "Dr. Rajashri Khanai", "role": ROLE_ADMIN,
        "department_name": "Computer Science & Engineering",
        "designation": "Professor & Head of Department",
        "office_room": "CS-101 (HOD Chamber)",
    },
    {
        "user_id": "usr-coord-001", "email": "coordinator@auro.edu", "password": "coord123",
        "full_name": "Dr. Priyanka Gavade", "role": ROLE_COORDINATOR,
        "department_name": "Computer Science & Engineering",
        "designation": "Assistant Professor & Timetable Officer",
        "office_room": "CS-104 (Faculty Block A)",
    },
    {
        "user_id": "usr-fac-001", "email": "salma@auro.edu", "password": "faculty123",
        "full_name": "Dr. Salma Shahapur", "role": ROLE_FACULTY,
        "department_name": "Computer Science & Engineering",
        "designation": "Associate Professor (Deep Learning)",
        "office_room": "CS-205 (Faculty Block A)",
        "faculty_id": "salma",
    },
    {
        "user_id": "usr-fac-002", "email": "amey@auro.edu", "password": "faculty123",
        "full_name": "Prof. Amey Muchandi", "role": ROLE_FACULTY,
        "department_name": "Computer Science & Engineering",
        "designation": "Assistant Professor (Embedded Systems)",
        "office_room": "CS-210 (Faculty Block A)",
        "faculty_id": "amey",
    },
    {
        "user_id": "usr-stu-001", "email": "student.a@auro.edu", "password": "student123",
        "full_name": "Aarav Kulkarni", "role": ROLE_STUDENT,
        "department_name": "Computer Science & Engineering",
        "division": "A", "batch": "B1", "roll_number": "01RU22CSE101",
    },
]

_USERS_BY_EMAIL: Dict[str, dict] = {}

_PUBLIC_FIELDS = (
    "user_id", "email", "full_name", "role", "department_name",
    "designation", "office_room", "division", "batch", "faculty_id", "roll_number",
)


def _hash(password: str) -> str:
    return hashlib.sha256((_SALT + password).encode()).hexdigest()


for _u in _USERS:
    _record = dict(_u)
    _record["password_hash"] = _hash(_record.pop("password"))
    _USERS_BY_EMAIL[_record["email"].lower()] = _record


def verify_password(email: str, password: str) -> Optional[dict]:
    record = _USERS_BY_EMAIL.get(email.strip().lower())
    if record is None or record["password_hash"] != _hash(password):
        return None
    return {field: record.get(field) for field in _PUBLIC_FIELDS}


def public_user(record: dict) -> dict:
    return {field: record.get(field) for field in _PUBLIC_FIELDS}
