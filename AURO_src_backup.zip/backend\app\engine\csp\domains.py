"""
CSP domain builder.

For each activity the domain is the set of feasible (day, start, room)
triples: block starts legal for the duration, room type/capacity ignored
here (checked at validation), room unavailability windows removed and
faculty unavailability windows removed.
"""

from typing import Dict, List

from ..core.types import (
    PERIOD_BLOCK_STARTS,
    Day,
    DomainValue,
    PeriodId,
    SchedulingProblem,
    TimeSlot,
)


def _cover_periods(problem: SchedulingProblem, start: PeriodId, duration: int) -> List[TimeSlot]:
    start_index = next(s.index for s in problem.slots if s.id == start)
    return [s for s in problem.slots if start_index <= s.index < start_index + duration]


def _faculty_available(problem: SchedulingProblem, faculty_id: str, day: Day, period: PeriodId) -> bool:
    for u in problem.unavailability:
        if u.resource_type == "faculty" and u.resource_id == faculty_id and u.day == day and u.period == period:
            return False
    return problem.faculty_availability.get(faculty_id, {}).get(f"{day}:{period}", True)


def _room_active(problem: SchedulingProblem, room_id: str, day: Day, periods: List[TimeSlot]) -> bool:
    period_ids = {p.id for p in periods}
    for u in problem.unavailability:
        if u.resource_type == "room" and u.resource_id == room_id and u.day == day and u.period in period_ids:
            return False
    return True


def build_domains(problem: SchedulingProblem) -> Dict[str, List[DomainValue]]:
    domains: Dict[str, List[DomainValue]] = {}

    for activity in problem.activities:
        values: List[DomainValue] = []
        starts = PERIOD_BLOCK_STARTS.get(activity.duration, PERIOD_BLOCK_STARTS[1])

        for day in problem.days:
            for start in starts:
                periods = _cover_periods(problem, start, activity.duration)
                if len(periods) < activity.duration:
                    continue

                for room_id in activity.allowed_room_ids:
                    if not _room_active(problem, room_id, day, periods):
                        continue

                    if not all(
                        _faculty_available(problem, fid, day, p.id)
                        for fid in activity.faculty_ids
                        for p in periods
                    ):
                        continue

                    values.append(DomainValue(day, start, room_id, [p.id for p in periods]))

        domains[activity.id] = values
    return domains
