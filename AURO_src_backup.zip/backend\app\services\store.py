"""
In-memory application stores: bearer-token sessions and the latest
generated timetable (shared across all dashboards).
"""

import uuid
from datetime import datetime, timedelta
from typing import Dict, Optional


class SessionStore:
    TTL = timedelta(hours=24)

    def __init__(self) -> None:
        self._sessions: Dict[str, dict] = {}

    def create(self, user: dict) -> str:
        token = f"auro_{uuid.uuid4()}"
        self._sessions[token] = {"user": user, "created_at": datetime.now()}
        return token

    def get(self, token: Optional[str]) -> Optional[dict]:
        if not token:
            return None
        session = self._sessions.get(token)
        if session is None:
            return None
        if datetime.now() - session["created_at"] > self.TTL:
            del self._sessions[token]
            return None
        return session["user"]

    def revoke(self, token: Optional[str]) -> None:
        if token:
            self._sessions.pop(token, None)


class TimetableStore:
    """Caches the most recent generation result for all dashboards."""

    def __init__(self) -> None:
        self._current: Optional[dict] = None

    def set(self, payload: dict) -> None:
        self._current = payload

    def get(self) -> Optional[dict]:
        return self._current


session_store = SessionStore()
timetable_store = TimetableStore()
