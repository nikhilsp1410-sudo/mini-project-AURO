export type UserRole = 'admin' | 'coordinator' | 'faculty' | 'student';

export interface User {
  user_id: string;
  email: string;
  full_name: string;
  role: UserRole;
  department_name: string;
  designation?: string;
  division?: 'A' | 'B' | 'C' | 'D';
  office_room?: string;
  roll_number?: string;
}

export interface AuthResponse {
  access_token: string;
  token_type: string;
  user: User;
}

export interface DemoAccount {
  email: string;
  role: UserRole;
  roleLabel: string;
  full_name: string;
  description: string;
  badgeColor: string;
  location: string;
  cohort: string;
}
