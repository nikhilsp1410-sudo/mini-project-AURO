import React, { useState } from 'react';
import { KLE_TIMETABLE_ENTRIES } from '../../data/timetableData';
import { BookMarked } from 'lucide-react';
import { Division } from '../../engine';

const PERIOD_ROWS = [
  { label: '08:00 – 09:00', start: '08:00' },
  { label: '09:00 – 10:00', start: '09:00' },
  { label: '10:30 – 11:30', start: '10:30' },
  { label: '11:30 – 12:30', start: '11:30' },
  { label: '01:30 – 03:30', start: '01:30' },
  { label: '03:30 – 04:30', start: '03:30' },
];

const GRID_DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] as const;

const rowIndexOf = (start: string) => PERIOD_ROWS.findIndex((r) => r.start === start);

const typeTone = (type: string) => {
  switch (type) {
    case 'theory':
      return 'text-blue-700 bg-blue-50/80 border-blue-200';
    case 'lab':
      return 'text-purple-700 bg-purple-50/80 border-purple-200';
    case 'project':
      return 'text-amber-800 bg-amber-50/80 border-amber-200';
    default:
      return 'text-emerald-700 bg-emerald-50/80 border-emerald-200';
  }
};

const ReferenceGrid: React.FC<{ division: Division }> = ({ division }) => {
  const entries = KLE_TIMETABLE_ENTRIES.filter((e) => e.division === division);

  const cellMap = new Map<string, typeof entries>();
  const spanning = new Set<string>();
  entries.forEach((e) => {
    const start = e.time.split(' - ')[0];
    const row = rowIndexOf(start);
    if (row < 0) return;
    const key = `${e.day}-${row}`;
    if (!cellMap.has(key)) cellMap.set(key, []);
    cellMap.get(key)!.push(e);
    if (start === '01:30' && e.duration >= 3 && cellMap.get(key)!.length === 1) {
      spanning.add(e.day);
    }
  });

  return (
    <div className="rounded-2xl border border-stone-300 bg-[#FDFBF6] shadow-sm overflow-hidden">
      <div className="px-5 py-3 border-b border-stone-200 flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="font-mono text-[10px] font-bold tracking-[0.2em] text-brand-700">
            REFERENCE BENCHMARK · DIVISION {division}
          </div>
          <div className="text-[11px] text-stone-500 font-medium mt-0.5">
            B.E. Computer Science — Section {division} · Semester V · 2026–27
          </div>
        </div>
        <span className="text-[9px] font-mono tracking-widest text-stone-400 border border-stone-200 rounded-full px-2.5 py-1">
          W.E.F 07 SEP 2026
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-[10px]" style={{ minWidth: 640 }}>
          <thead>
            <tr className="bg-stone-50 border-b border-stone-200">
              <th className="px-3 py-2 text-left font-mono text-[9px] font-bold tracking-widest text-stone-500 border-r border-stone-200 w-[104px]">
                PERIOD
              </th>
              {GRID_DAYS.map((d) => (
                <th key={d} className="px-2 py-2 text-center font-mono text-[9.5px] font-bold tracking-widest text-stone-600">
                  {d.toUpperCase()}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {PERIOD_ROWS.map((period, row) => (
              <React.Fragment key={period.label}>
                {row === 4 && (
                  <tr className="border-y border-stone-200 bg-stone-50/80">
                    <td colSpan={7} className="px-3 py-1 text-center font-mono text-[9px] font-bold tracking-[0.3em] text-stone-400">
                      LUNCH RECESS · 12:30 – 01:30
                    </td>
                  </tr>
                )}
                <tr className="border-b border-stone-100">
                  <td className="px-3 py-1.5 border-r border-stone-200 font-mono text-[9.5px] font-bold text-stone-600 whitespace-nowrap align-middle">
                    {period.label}
                  </td>
                  {GRID_DAYS.map((day) => {
                    if (row === 5 && spanning.has(day)) return null;
                    const cellEntries = cellMap.get(`${day}-${row}`) ?? [];
                    return (
                      <td
                        key={day}
                        rowSpan={cellEntries.length === 1 && period.start === '01:30' && cellEntries[0].duration >= 3 ? 2 : 1}
                        className="px-1.5 py-1 align-top border-r border-stone-100 last:border-r-0"
                      >
                        {cellEntries.length === 0 ? (
                          <div className="h-[28px] flex items-center justify-center text-stone-300">·</div>
                        ) : (
                          <div className="space-y-1 h-full">
                            {cellEntries.map((e) => (
                              <div
                                key={e.id}
                                title={`${e.subject} · ${e.faculty}`}
                                className={`px-1.5 py-1 rounded border ${typeTone(e.type)} leading-tight`}
                              >
                                <div className="font-mono font-bold text-[9px] truncate">{e.code}</div>
                                <div className="text-[8.5px] font-mono text-stone-500 truncate">{e.room}</div>
                              </div>
                            ))}
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      <div className="px-5 py-2 border-t border-stone-200 bg-stone-50/60 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-3 font-mono text-[8.5px] tracking-wider text-stone-500">
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm bg-blue-200 border border-blue-300" /> THEORY</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm bg-purple-200 border border-purple-300" /> LAB</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm bg-amber-200 border border-amber-300" /> PROJECT</span>
        </div>
        <span className="font-mono text-[8.5px] tracking-widest text-stone-400">
          KLE TECH GROUND-TRUTH BENCHMARK
        </span>
      </div>
    </div>
  );
};

export const ReferencePage: React.FC = () => {
  const [division, setDivision] = useState<Division>('A');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="rounded-2xl border border-stone-300 bg-[#FDFBF6] p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 font-mono text-[10px] font-bold tracking-[0.25em] text-brand-700">
              <BookMarked className="w-3.5 h-3.5" />
              KLE TECH REFERENCE TIMETABLE · MANDATORY INVARIANT SPEC
            </div>
            <h1 className="font-serif text-2xl font-black tracking-tight text-stone-900 mt-1.5">
              Ground-Truth Benchmark
            </h1>
            <p className="text-xs text-stone-500 mt-1.5 max-w-xl">
              The real operational timetables of KLE Technological University (CSE V Semester,
              Divisions A–D). AURO's generation engine treats these invariants as the validation
              model for every schedule it produces.
            </p>
          </div>
          <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-lg border border-stone-200">
            {(['A', 'B', 'C', 'D'] as Division[]).map((d) => (
              <button
                key={d}
                onClick={() => setDivision(d)}
                className={`px-3.5 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer ${
                  division === d ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                Div {d}
              </button>
            ))}
          </div>
        </div>
      </div>

      <ReferenceGrid division={division} />
    </div>
  );
};
