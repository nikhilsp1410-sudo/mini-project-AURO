"""
Conflict Graph — vertices are schedulable activities; an edge joins two
activities that share at least one resource:
  - faculty:  any common faculty member
  - group:    the same student group
  - room:     rival rooms (both list the same room among their allowed rooms)

Two adjacent activities can never occupy overlapping periods.
"""

from typing import Dict, List, Optional, Set, Tuple

from ..core.types import Activity

ConflictReason = str  # 'faculty' | 'group' | 'room'


def _edge_key(u: str, v: str) -> Tuple[str, str]:
    return (u, v) if u < v else (v, u)


class ConflictGraph:
    def __init__(self) -> None:
        self.vertices: Dict[str, Activity] = {}
        self.adjacency: Dict[str, Set[str]] = {}
        self._edge_reasons: Dict[Tuple[str, str], Set[ConflictReason]] = {}

    def add_vertex(self, activity: Activity) -> None:
        if activity.id in self.vertices:
            return
        self.vertices[activity.id] = activity
        self.adjacency[activity.id] = set()

    def add_edge(self, u: str, v: str, reason: ConflictReason) -> None:
        if u == v or u not in self.adjacency or v not in self.adjacency:
            return
        self.adjacency[u].add(v)
        self.adjacency[v].add(u)
        self._edge_reasons.setdefault(_edge_key(u, v), set()).add(reason)

    def get_neighbors(self, activity_id: str) -> Set[str]:
        return self.adjacency.get(activity_id, set())

    def get_degree(self, activity_id: str) -> int:
        return len(self.adjacency.get(activity_id, ()))

    @property
    def edge_count(self) -> int:
        return len(self._edge_reasons)

    @property
    def edges_by_reason(self) -> Dict[str, int]:
        counts = {"faculty": 0, "group": 0, "room": 0}
        for reasons in self._edge_reasons.values():
            for reason in reasons:
                counts[reason] += 1
        return counts

    @staticmethod
    def build(activities: List[Activity]) -> "ConflictGraph":
        graph = ConflictGraph()
        for activity in activities:
            graph.add_vertex(activity)

        for i in range(len(activities)):
            for j in range(i + 1, len(activities)):
                a, b = activities[i], activities[j]
                if any(f in b.faculty_ids for f in a.faculty_ids):
                    graph.add_edge(a.id, b.id, "faculty")
                if a.group_id == b.group_id:
                    graph.add_edge(a.id, b.id, "group")
                if any(r in b.allowed_room_ids for r in a.allowed_room_ids):
                    graph.add_edge(a.id, b.id, "room")
        return graph
