"""
AURO backend — FastAPI application.

Hosts the DSA timetable-generation engine (engine-wise package under
app/engine/) and exposes it over REST for the React frontend.

Run:  uvicorn app.main:app --reload --port 8000
"""

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routes.auth_routes import router as auth_router
from .routes.timetable_routes import router as timetable_router

app = FastAPI(
    title="AURO Backend",
    description="Autonomous University Resource Orchestrator — DSA timetable engine API",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/v1/health", tags=["health"])
def health():
    return {"status": "ok", "service": "auro-backend", "engines": ["dsa"]}


app.include_router(auth_router)
app.include_router(timetable_router)


if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=False)
